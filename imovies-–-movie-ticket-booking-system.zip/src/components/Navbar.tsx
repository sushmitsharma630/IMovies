import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { Film, User as UserIcon, LogOut, ShieldAlert, Ticket } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openAuthModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, openAuthModal }) => {
  const { user, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#080b12]/90 backdrop-blur-md border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors cursor-pointer"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-sm">
            <Film className="w-4 h-4 stroke-[2.5]" />
          </div>
          <span className="font-display tracking-wider text-xl font-extrabold uppercase">
            I<span className="text-amber-400">Movies</span>
          </span>
        </button>

        {/* Zone 2: Concise Nav Links (Single line) */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
          <button
            onClick={() => setActiveTab('home')}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'home' ? 'text-amber-400 font-semibold' : 'hover:text-white'
            }`}
          >
            Movies
          </button>
          <button
            onClick={() => {
              setActiveTab('home');
              const el = document.getElementById('now-showing-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Showtimes
          </button>
          <button
            onClick={() => {
              setActiveTab('home');
              const el = document.getElementById('experience-section');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Experience
          </button>
          <button
            onClick={() => {
              if (!user) {
                openAuthModal();
              } else {
                setActiveTab('my-bookings');
              }
            }}
            className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'my-bookings' ? 'text-amber-400 font-semibold' : 'hover:text-white'
            }`}
          >
            My Bookings
          </button>
          {user?.role === 'admin' && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'admin' ? 'text-amber-400 font-semibold' : 'text-amber-300 hover:text-amber-200'
              }`}
            >
              Admin Console
            </button>
          )}
        </nav>

        {/* Zone 3: 1 Primary Action Area */}
        <div className="flex items-center gap-3 shrink-0 relative">
          {user ? (
            <div className="relative">
              <button
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-900 border border-slate-700/80 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <div className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="max-w-[120px] truncate">{user.name}</span>
                {user.role === 'admin' && (
                  <span className="text-[10px] text-amber-400 uppercase font-mono tracking-wider ml-1">Admin</span>
                )}
              </button>

              {dropdownOpen && (
                <div
                  className="absolute right-0 mt-2 w-56 bg-slate-900/95 border border-slate-800 rounded-xl shadow-2xl py-2 z-50 text-xs backdrop-blur-md"
                  onClick={() => setDropdownOpen(false)}
                >
                  <div className="px-3.5 py-2 border-b border-slate-800">
                    <p className="font-semibold text-slate-200 truncate">{user.name}</p>
                    <p className="text-slate-400 text-[11px] truncate">{user.email}</p>
                  </div>

                  <button
                    onClick={() => setActiveTab('my-bookings')}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors text-left cursor-pointer"
                  >
                    <Ticket className="w-3.5 h-3.5 text-amber-400" />
                    <span>My Bookings</span>
                  </button>

                  {user.role === 'admin' && (
                    <button
                      onClick={() => setActiveTab('admin')}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-amber-300 hover:text-amber-200 hover:bg-slate-800/80 transition-colors text-left cursor-pointer"
                    >
                      <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                      <span>Admin Dashboard</span>
                    </button>
                  )}

                  <div className="border-t border-slate-800 mt-1 pt-1">
                    <button
                      onClick={logout}
                      className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-rose-400 hover:text-rose-300 hover:bg-slate-800/80 transition-colors text-left cursor-pointer"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={openAuthModal}
              className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm shadow-amber-500/20 cursor-pointer flex items-center gap-1.5"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span>Sign In / Demo</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

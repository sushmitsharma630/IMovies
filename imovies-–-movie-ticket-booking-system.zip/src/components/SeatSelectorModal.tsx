import React, { useState } from 'react';
import { Movie, Showtime, BookedSeatItem } from '../types/index.ts';
import { X, Armchair, AlertCircle, ArrowRight, ShieldCheck, Check } from 'lucide-react';

interface SeatSelectorModalProps {
  movie: Movie;
  showtime: Showtime;
  onClose: () => void;
  onProceedToCheckout: (selectedSeats: BookedSeatItem[], showtime: Showtime, movie: Movie) => void;
}

export const SeatSelectorModal: React.FC<SeatSelectorModalProps> = ({
  movie,
  showtime,
  onClose,
  onProceedToCheckout,
}) => {
  const [selectedSeats, setSelectedSeats] = useState<BookedSeatItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Seat Configuration: 8 Rows (A-H), 8 Columns (1-8)
  const rows = [
    { rowLetter: 'H', tier: 'platinum' as const, label: 'Platinum Recliner' },
    { rowLetter: 'G', tier: 'platinum' as const, label: 'Platinum Recliner' },
    { rowLetter: 'F', tier: 'platinum' as const, label: 'Platinum Recliner' },
    { rowLetter: 'E', tier: 'gold' as const, label: 'Gold Club' },
    { rowLetter: 'D', tier: 'gold' as const, label: 'Gold Club' },
    { rowLetter: 'C', tier: 'gold' as const, label: 'Gold Club' },
    { rowLetter: 'B', tier: 'silver' as const, label: 'Silver Executive' },
    { rowLetter: 'A', tier: 'silver' as const, label: 'Silver Executive' },
  ];

  const cols = [1, 2, 3, 4, 5, 6, 7, 8];

  const bookedSet = new Set(showtime.bookedSeats || []);

  const handleSeatClick = (seatNumber: string, tier: 'silver' | 'gold' | 'platinum') => {
    setErrorMessage(null);

    // If booked, do nothing
    if (bookedSet.has(seatNumber)) {
      return;
    }

    const exists = selectedSeats.find((s) => s.seatNumber === seatNumber);

    if (exists) {
      // Deselect
      setSelectedSeats(selectedSeats.filter((s) => s.seatNumber !== seatNumber));
    } else {
      // Max 8 seats limit per booking
      if (selectedSeats.length >= 8) {
        setErrorMessage('Maximum 8 seats allowed per single transaction.');
        return;
      }

      const price = showtime.pricing[tier] || 250;
      setSelectedSeats([...selectedSeats, { seatNumber, tier, price }]);
    }
  };

  // Pricing calculations
  const subtotal = selectedSeats.reduce((sum, s) => sum + s.price, 0);
  const convenienceFee = selectedSeats.length > 0 ? selectedSeats.length * 25 : 0;
  const taxAmount = Number(((subtotal + convenienceFee) * 0.09).toFixed(2));
  const grandTotal = Number((subtotal + convenienceFee + taxAmount).toFixed(2));

  const handleProceed = () => {
    if (selectedSeats.length === 0) {
      setErrorMessage('Please select at least 1 seat to continue.');
      return;
    }
    onProceedToCheckout(selectedSeats, showtime, movie);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#090d18] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-6 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
              <Armchair className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold uppercase">
                <span>{movie.title}</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-400">{showtime.format}</span>
              </div>
              <p className="text-xs text-slate-300">
                {showtime.cinemaHall} · {showtime.date} at <span className="font-bold text-white font-mono-num">{showtime.time}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Seat Map & Price Breakdown Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Curved Screen & Seat Matrix */}
          <div className="lg:col-span-8 flex flex-col items-center">
            {/* Curved Cinema Screen */}
            <div className="w-full max-w-xl mx-auto mb-8 text-center">
              <div className="h-2 w-full bg-gradient-to-r from-transparent via-amber-400 to-transparent rounded-full shadow-lg shadow-amber-400/40" />
              <div className="h-10 w-full bg-gradient-to-b from-amber-400/15 to-transparent cinema-screen-curve rounded-t-xl mt-1 border-t border-amber-300/30 flex items-center justify-center">
                <span className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">
                  ALL EYES ON THE CINEMA SCREEN
                </span>
              </div>
            </div>

            {/* Seat Grid Layout */}
            <div className="w-full max-w-md sm:max-w-lg space-y-3">
              {rows.map((row) => (
                <div key={row.rowLetter} className="flex items-center justify-between gap-1 sm:gap-2">
                  {/* Row Identifier */}
                  <span className="w-5 text-center text-xs font-bold text-slate-500 font-mono-num">
                    {row.rowLetter}
                  </span>

                  {/* Seats in Row */}
                  <div className="flex-1 flex items-center justify-center gap-1.5 sm:gap-2.5">
                    {cols.map((col, idx) => {
                      const seatId = `${row.rowLetter}${col}`;
                      const isBooked = bookedSet.has(seatId);
                      const isSelected = selectedSeats.some((s) => s.seatNumber === seatId);

                      // Aisle break between seat 4 and 5
                      const hasAisleGap = idx === 3;

                      return (
                        <React.Fragment key={seatId}>
                          <button
                            disabled={isBooked}
                            onClick={() => handleSeatClick(seatId, row.tier)}
                            title={
                              isBooked
                                ? `Seat ${seatId} (Booked)`
                                : isSelected
                                ? `Seat ${seatId} (Selected: ₹${showtime.pricing[row.tier]})`
                                : `Seat ${seatId} (${row.label}: ₹${showtime.pricing[row.tier]})`
                            }
                            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center text-[11px] font-mono-num font-semibold transition-all cursor-pointer ${
                              isBooked
                                ? 'bg-slate-900 border border-slate-800 text-slate-600 cursor-not-allowed opacity-40 line-through'
                                : isSelected
                                ? 'bg-amber-400 border border-amber-300 text-slate-950 font-bold shadow-md shadow-amber-400/30 scale-105'
                                : 'bg-slate-800/80 hover:bg-slate-700 border border-slate-700/80 text-slate-300 hover:border-amber-400/60'
                            }`}
                          >
                            {isSelected ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : col}
                          </button>
                          {hasAisleGap && <div className="w-3 sm:w-6" />}
                        </React.Fragment>
                      );
                    })}
                  </div>

                  {/* Right Row Letter */}
                  <span className="w-5 text-center text-xs font-bold text-slate-500 font-mono-num">
                    {row.rowLetter}
                  </span>
                </div>
              ))}
            </div>

            {/* Seat Status Legend */}
            <div className="flex flex-wrap items-center justify-center gap-6 mt-8 pt-4 border-t border-slate-800/80 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-slate-800 border border-slate-700" />
                <span>Available</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-amber-400 border border-amber-300 shadow-sm" />
                <span className="text-amber-400 font-medium">Selected</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-slate-900 border border-slate-800 opacity-40" />
                <span className="text-slate-500">Booked / Taken</span>
              </div>
            </div>

            {/* Tier Guide */}
            <div className="flex flex-wrap items-center justify-center gap-4 mt-3 text-[11px] text-slate-400 font-mono-num">
              <span>Silver (Rows A-B): ₹{showtime.pricing.silver}</span>
              <span aria-hidden="true">·</span>
              <span>Gold (Rows C-E): ₹{showtime.pricing.gold}</span>
              <span aria-hidden="true">·</span>
              <span>Platinum (Rows F-H): ₹{showtime.pricing.platinum}</span>
            </div>
          </div>

          {/* Right Column: Order Summary & Checkout Panel */}
          <div className="lg:col-span-4 bg-slate-900/70 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-white mb-3 font-display">Booking Summary</h3>

              {/* Selected Seats List */}
              <div className="mb-4">
                <span className="text-xs text-slate-400 block mb-2">Selected Seats ({selectedSeats.length})</span>
                {selectedSeats.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No seats selected yet. Click on any seat above to pick.</p>
                ) : (
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                    {selectedSeats.map((s) => (
                      <span
                        key={s.seatNumber}
                        className="px-2.5 py-1 rounded-md bg-amber-400/10 border border-amber-400/30 text-amber-300 font-mono-num text-xs font-semibold flex items-center gap-1.5"
                      >
                        <span>{s.seatNumber}</span>
                        <span className="text-[10px] text-slate-400">({s.tier})</span>
                        <span className="text-[10px] text-amber-400">₹{s.price}</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Price Calculation */}
              <div className="border-t border-slate-800 pt-3 space-y-2 text-xs font-mono-num">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Tickets Subtotal</span>
                  <span className="text-slate-200">₹{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Convenience Fee (₹25/tkt)</span>
                  <span className="text-slate-200">₹{convenienceFee.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>GST / Tax (9%)</span>
                  <span className="text-slate-200">₹{taxAmount.toFixed(2)}</span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-sm font-bold text-white">
                  <span>Grand Total</span>
                  <span className="text-amber-400 text-base">₹{grandTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Concurrency Guarantee Badge */}
              <div className="mt-4 p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Seats are verified in real time with atomic collision protection to guarantee zero double-bookings.
                </span>
              </div>
            </div>

            {/* Bottom Checkout CTA */}
            <div className="mt-6 pt-4 border-t border-slate-800">
              <button
                disabled={selectedSeats.length === 0}
                onClick={handleProceed}
                className={`w-full py-3 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  selectedSeats.length > 0
                    ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Movie } from '../types/index.ts';
import { Play, Ticket, Star, Clock, Calendar, Volume2, X } from 'lucide-react';

interface HeroBannerProps {
  movie?: Movie;
  onSelectMovie: (movie: Movie) => void;
  onExploreClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ movie, onSelectMovie, onExploreClick }) => {
  const [showTrailer, setShowTrailer] = useState(false);

  if (!movie) {
    return null;
  }

  return (
    <section className="relative w-full overflow-hidden border-b border-slate-800/60 bg-[#0a0e17]">
      {/* Background Cinematic Atmosphere */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src={movie.bannerUrl || movie.posterUrl}
          alt={movie.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-25 filter blur-sm scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080b12] via-[#080b12]/85 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#080b12] via-[#080b12]/70 to-transparent" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Film Details */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Clean Unboxed Metadata Kicker */}
            <div className="flex items-center gap-2 text-xs font-medium text-amber-400 tracking-wide mb-3">
              <span>FEATURED PREMIERE</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-300">{movie.language}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-300">{movie.rating}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight mb-4 font-display text-balance">
              {movie.title}
            </h1>

            {/* Movie Stats Line */}
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 mb-5 font-mono-num">
              <div className="flex items-center gap-1.5 text-amber-400">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="font-semibold text-white">{movie.imdbRating.toFixed(1)}</span>
                <span className="text-slate-400">/ 10 IMDb</span>
              </div>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <div className="flex items-center gap-1 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{movie.duration} min</span>
              </div>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <div className="flex items-center gap-1 text-slate-300">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{movie.releaseDate}</span>
              </div>
            </div>

            <p className="text-sm sm:text-base text-slate-300/90 leading-relaxed mb-6 max-w-2xl">
              {movie.description}
            </p>

            {/* Cast & Director in quiet text */}
            <div className="text-xs text-slate-400 space-y-1 mb-8">
              <p>
                <span className="text-slate-500 font-medium">Director:</span>{' '}
                <span className="text-slate-200">{movie.director || 'Visionary Filmmakers'}</span>
              </p>
              <p>
                <span className="text-slate-500 font-medium">Starring:</span>{' '}
                <span className="text-slate-200">{movie.cast?.join(', ') || 'Ensemble Cast'}</span>
              </p>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => onSelectMovie(movie)}
                className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-sm rounded-xl transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Ticket className="w-4 h-4" />
                <span>Book Tickets Now</span>
              </button>

              {movie.trailerUrl && (
                <button
                  onClick={() => setShowTrailer(true)}
                  className="px-5 py-3 bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-medium text-sm rounded-xl transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Play className="w-4 h-4 text-amber-400 fill-amber-400" />
                  <span>Watch Trailer</span>
                </button>
              )}

              <button
                onClick={onExploreClick}
                className="px-4 py-3 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                Browse All Movies ↓
              </button>
            </div>
          </div>

          {/* Right Column: Poster Card */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative group max-w-xs sm:max-w-sm rounded-2xl overflow-hidden shadow-2xl border border-slate-800 bg-slate-900 transition-transform duration-300 hover:scale-[1.02]">
              <div className="aspect-[3/4] w-full overflow-hidden bg-slate-950">
                <img
                  src={movie.posterUrl}
                  alt={movie.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>

              {/* Subdued overlay info */}
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-5">
                <div className="flex items-center justify-between text-xs text-slate-300 font-mono-num mb-1">
                  <span>IMAX Dolby 3D</span>
                  <span className="text-amber-400 font-semibold">From ₹280</span>
                </div>
                <p className="text-xs text-slate-400 truncate">Screen 1 & 2 · Multiple Showtimes Daily</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trailer Modal */}
      {showTrailer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <div className="flex items-center gap-2 text-sm font-semibold text-white">
                <Volume2 className="w-4 h-4 text-amber-400" />
                <span>{movie.title} – Official Cinema Preview</span>
              </div>
              <button
                onClick={() => setShowTrailer(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video w-full bg-black">
              <iframe
                src={`https://www.youtube.com/embed/${movie.trailerUrl ? movie.trailerUrl.split('v=')[1] || 'zSWdZVtXT7E' : 'zSWdZVtXT7E'}?autoplay=1`}
                title={movie.title}
                className="w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

import React, { useState } from 'react';
import { Movie, Showtime, BookedSeatItem, Booking } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { X, CreditCard, QrCode, Building, Banknote, ShieldAlert, CheckCircle2, Loader2, Lock } from 'lucide-react';

interface CheckoutModalProps {
  movie: Movie;
  showtime: Showtime;
  selectedSeats: BookedSeatItem[];
  onClose: () => void;
  onBookingSuccess: (booking: Booking) => void;
  openAuthModal: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  movie,
  showtime,
  selectedSeats,
  onClose,
  onBookingSuccess,
  openAuthModal,
}) => {
  const { user } = useAuth();

  const [customerName, setCustomerName] = useState(user?.name || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState(user?.phone || '+91 98765 43210');
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'NetBanking' | 'Counter'>('UPI');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const subtotal = selectedSeats.reduce((sum, s) => sum + s.price, 0);
  const convenienceFee = selectedSeats.length * 25;
  const taxAmount = Number(((subtotal + convenienceFee) * 0.09).toFixed(2));
  const grandTotal = Number((subtotal + convenienceFee + taxAmount).toFixed(2));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setErrorMessage('Please sign in or register to complete your ticket booking.');
      openAuthModal();
      return;
    }

    if (!customerName || !customerEmail) {
      setErrorMessage('Name and Email address are required.');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await api.createBooking({
        showtimeId: showtime._id,
        movieId: movie._id,
        seats: selectedSeats,
        customerName,
        customerEmail,
        customerPhone,
        paymentMethod,
      });

      if (res.booking) {
        onBookingSuccess(res.booking);
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setErrorMessage(err.message || 'Payment processing or seat lock failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#0d121f] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2 text-sm font-bold text-white font-display">
            <Lock className="w-4 h-4 text-amber-400" />
            <span>Secure Cinema Ticket Checkout</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Not Logged In Notice */}
        {!user && (
          <div className="mx-6 mt-4 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center justify-between gap-3">
            <span>You need to be logged in to confirm ticket reservations.</span>
            <button
              onClick={openAuthModal}
              className="px-3 py-1.5 bg-amber-400 text-slate-950 font-semibold rounded-lg hover:bg-amber-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer text-xs"
            >
              Sign In Now
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Order Snapshot */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-amber-400 uppercase tracking-wide">{movie.title}</p>
              <p className="text-xs text-slate-300 mt-0.5">
                {showtime.cinemaHall} · {showtime.date} ({showtime.time})
              </p>
              <p className="text-[11px] text-slate-400 mt-1 font-mono-num">
                Seats: <span className="text-white font-bold">{selectedSeats.map((s) => s.seatNumber).join(', ')}</span> ({selectedSeats.length} tickets)
              </p>
            </div>
            <div className="text-left sm:text-right font-mono-num border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
              <span className="text-[10px] text-slate-500 uppercase block">Grand Total</span>
              <span className="text-lg font-bold text-amber-400">₹{grandTotal.toFixed(2)}</span>
            </div>
          </div>

          {/* Contact Details */}
          <div>
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
              1. Guest & Ticket Delivery Details
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-400"
                  placeholder="e.g. John Doe"
                />
              </div>
              <div>
                <label className="block text-slate-400 mb-1">Email (e-Ticket Receipt)</label>
                <input
                  type="email"
                  required
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-400"
                  placeholder="john@example.com"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-slate-400 mb-1">Phone Number (SMS Booking Code)</label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-400"
                  placeholder="+91 98765 43210"
                />
              </div>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
              2. Select Payment Method
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <button
                type="button"
                onClick={() => setPaymentMethod('UPI')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'UPI'
                    ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-5 h-5 text-amber-400" />
                <span>UPI / QR</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('Card')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'Card'
                    ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <CreditCard className="w-5 h-5 text-amber-400" />
                <span>Debit/Credit</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('NetBanking')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'NetBanking'
                    ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Building className="w-5 h-5 text-amber-400" />
                <span>Net Banking</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('Counter')}
                className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  paymentMethod === 'Counter'
                    ? 'bg-amber-400/10 border-amber-400 text-amber-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <Banknote className="w-5 h-5 text-amber-400" />
                <span>Box Office</span>
              </button>
            </div>
          </div>

          {/* Submit Action */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-medium text-slate-400 hover:text-white cursor-pointer"
            >
              Back to Seats
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md shadow-amber-400/20 flex items-center gap-2 cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Reserving Seats & Verifying...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Pay & Confirm ₹{grandTotal.toFixed(2)}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

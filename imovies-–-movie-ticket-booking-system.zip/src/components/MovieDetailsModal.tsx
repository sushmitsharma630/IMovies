import React, { useState, useEffect } from 'react';
import { Movie, Showtime } from '../types/index.ts';
import { api } from '../services/api.ts';
import { X, Clock, Calendar, Star, Film, Ticket, ChevronRight, Loader2 } from 'lucide-react';

interface MovieDetailsModalProps {
  movie: Movie | null;
  onClose: () => void;
  onSelectShowtime: (showtime: Showtime, movie: Movie) => void;
}

export const MovieDetailsModal: React.FC<MovieDetailsModalProps> = ({
  movie,
  onClose,
  onSelectShowtime,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [showtimes, setShowtimes] = useState<Showtime[]>([]);
  const [loadingShowtimes, setLoadingShowtimes] = useState(false);

  // Generate date options (Today + next 6 days)
  const dateOptions = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    const dateStr = d.toISOString().split('T')[0];
    const dayName = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString('en-US', { weekday: 'short' });
    const dayNum = d.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
    return { dateStr, dayName, dayNum };
  });

  useEffect(() => {
    if (dateOptions.length > 0 && !selectedDate) {
      setSelectedDate(dateOptions[0].dateStr);
    }
  }, []);

  useEffect(() => {
    if (!movie || !selectedDate) return;

    async function fetchShowtimes() {
      setLoadingShowtimes(true);
      try {
        const res = await api.getShowtimes({ movieId: movie!._id, date: selectedDate });
        setShowtimes(res.showtimes || []);
      } catch (err) {
        console.error('Failed to load showtimes', err);
        setShowtimes([]);
      } finally {
        setLoadingShowtimes(false);
      }
    }

    fetchShowtimes();
  }, [movie, selectedDate]);

  if (!movie) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#0d121f] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-xl bg-slate-900/80 border border-slate-700/60 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Hero / Backdrop */}
        <div className="relative aspect-[21/9] sm:aspect-[21/8] w-full overflow-hidden bg-slate-950">
          <img
            src={movie.bannerUrl || movie.posterUrl}
            alt={movie.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-35 filter blur-[2px]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d121f] via-[#0d121f]/75 to-transparent" />

          {/* Quick Info in Hero */}
          <div className="absolute bottom-4 left-6 right-6 flex items-end gap-6">
            <div className="hidden sm:block w-28 h-40 rounded-xl overflow-hidden shadow-2xl border border-slate-700/80 shrink-0 bg-slate-900">
              <img
                src={movie.posterUrl}
                alt={movie.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
                <span>{movie.status === 'now_showing' ? 'NOW IN CINEMAS' : 'RELEASING SOON'}</span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-300">{movie.language}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
                {movie.title}
              </h2>
              <div className="flex items-center gap-3 text-xs text-slate-300 mt-1 font-mono-num">
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-amber-400" />
                  {movie.imdbRating.toFixed(1)} / 10
                </span>
                <span aria-hidden="true">·</span>
                <span>{movie.duration} mins</span>
                <span aria-hidden="true">·</span>
                <span>{movie.rating}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {/* Synopsis & Cast */}
          <div className="mb-6">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Synopsis</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">{movie.description}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-900/60 border border-slate-800/80 rounded-xl p-3.5">
              <div>
                <span className="text-slate-500 font-medium">Director:</span>{' '}
                <span className="text-slate-200">{movie.director || 'N/A'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Genre:</span>{' '}
                <span className="text-slate-200">{movie.genre.join(', ')}</span>
              </div>
              <div className="sm:col-span-2">
                <span className="text-slate-500 font-medium">Starring:</span>{' '}
                <span className="text-slate-200">{movie.cast.join(', ') || 'N/A'}</span>
              </div>
            </div>
          </div>

          {/* Showtimes & Booking Section */}
          <div className="border-t border-slate-800 pt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white font-display">Select Date & Showtime</h3>
              </div>
              <span className="text-[11px] text-slate-400 font-mono-num">Showing in 3 Auditoriums</span>
            </div>

            {/* Date Selector Row */}
            <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-none">
              {dateOptions.map((opt) => (
                <button
                  key={opt.dateStr}
                  onClick={() => setSelectedDate(opt.dateStr)}
                  className={`flex flex-col items-center justify-center min-w-[72px] py-2.5 px-3 rounded-xl border text-xs transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    selectedDate === opt.dateStr
                      ? 'bg-amber-400 text-slate-950 border-amber-400 font-semibold shadow-md shadow-amber-500/20'
                      : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  <span className="text-[11px] uppercase tracking-wide">{opt.dayName}</span>
                  <span className="text-sm font-bold font-mono-num">{opt.dayNum}</span>
                </button>
              ))}
            </div>

            {/* Showtimes list */}
            {loadingShowtimes ? (
              <div className="flex items-center justify-center py-10 gap-2 text-xs text-slate-400">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span>Loading available cinema showtimes...</span>
              </div>
            ) : showtimes.length === 0 ? (
              <div className="text-center py-8 bg-slate-900/40 rounded-xl border border-slate-800/80">
                <Film className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400">No showtimes scheduled for this date.</p>
                <p className="text-[11px] text-slate-500 mt-1">Please pick another date or select another movie.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {showtimes.map((st) => (
                  <div
                    key={st._id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-slate-900/80 border border-slate-800 rounded-xl hover:border-slate-700 transition-colors gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-white">{st.cinemaHall}</span>
                        <span className="text-[10px] font-mono-num px-2 py-0.5 rounded bg-slate-800 text-amber-400 border border-amber-500/20">
                          {st.format}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono-num">
                        <span>Silver: ₹{st.pricing.silver}</span>
                        <span aria-hidden="true">·</span>
                        <span>Gold: ₹{st.pricing.gold}</span>
                        <span aria-hidden="true">·</span>
                        <span>Platinum: ₹{st.pricing.platinum}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                      <div className="text-left sm:text-right">
                        <span className="text-sm font-extrabold text-white font-mono-num block">{st.time}</span>
                        <span className="text-[10px] text-emerald-400">
                          {(st.totalSeats || 64) - (st.bookedSeats?.length || 0)} seats left
                        </span>
                      </div>

                      <button
                        onClick={() => onSelectShowtime(st, movie)}
                        className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-sm shadow-amber-500/20"
                      >
                        <Ticket className="w-3.5 h-3.5" />
                        <span>Select Seats</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Movie, Showtime, Booking, CinemaStats } from '../types/index.ts';
import { api } from '../services/api.ts';
import {
  Film,
  Calendar,
  Ticket,
  BarChart3,
  Plus,
  Trash2,
  Edit2,
  Search,
  CheckCircle2,
  AlertCircle,
  Loader2,
  IndianRupee,
  Users,
  Armchair,
  X,
} from 'lucide-react';

interface AdminDashboardProps {
  onBackToMovies: () => void;
  movies: Movie[];
  refreshMovies: () => Promise<void>;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onBackToMovies,
  movies,
  refreshMovies,
}) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'movies' | 'showtimes' | 'bookings'>('analytics');
  const [stats, setStats] = useState<CinemaStats | null>(null);
  const [showtimes, setShowtimes] = useState<Showtime[]>([]);
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Movie Modal state
  const [showMovieModal, setShowMovieModal] = useState(false);
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);
  const [movieForm, setMovieForm] = useState({
    title: '',
    description: '',
    genre: 'Action, Thriller',
    duration: 135,
    rating: 'UA 16+',
    imdbRating: 8.5,
    releaseDate: '2026-10-25',
    posterUrl: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg',
    director: '',
    cast: '',
    language: 'English',
    status: 'now_showing' as 'now_showing' | 'coming_soon',
    featured: false,
  });

  // Showtime Modal state
  const [showShowtimeModal, setShowShowtimeModal] = useState(false);
  const [showtimeForm, setShowtimeForm] = useState({
    movieId: '',
    cinemaHall: 'Screen 1 – IMAX Laser & Dolby Atmos',
    date: new Date().toISOString().split('T')[0],
    time: '06:30 PM',
    format: 'IMAX 3D',
    pricing: { silver: 280, gold: 420, platinum: 600 },
  });

  // Booking search
  const [bookingSearch, setBookingSearch] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [statsRes, showtimesRes, bookingsRes] = await Promise.all([
        api.getCinemaStats().catch(() => ({ stats: null })),
        api.getShowtimes().catch(() => ({ showtimes: [] })),
        api.getAllBookings().catch(() => ({ bookings: [] })),
      ]);

      if (statsRes.stats) setStats(statsRes.stats);
      if (showtimesRes.showtimes) setShowtimes(showtimesRes.showtimes);
      if (bookingsRes.bookings) setAllBookings(bookingsRes.bookings);
    } catch (err: any) {
      console.error('Failed to load admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Set default movie for showtime form when movies load
  useEffect(() => {
    if (movies.length > 0 && !showtimeForm.movieId) {
      setShowtimeForm((prev) => ({ ...prev, movieId: movies[0]._id }));
    }
  }, [movies]);

  // Movie actions
  const handleOpenAddMovie = () => {
    setEditingMovie(null);
    setMovieForm({
      title: '',
      description: '',
      genre: 'Action, Sci-Fi',
      duration: 135,
      rating: 'UA 16+',
      imdbRating: 8.5,
      releaseDate: new Date().toISOString().split('T')[0],
      posterUrl: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg',
      director: '',
      cast: '',
      language: 'English',
      status: 'now_showing',
      featured: false,
    });
    setShowMovieModal(true);
  };

  const handleOpenEditMovie = (m: Movie) => {
    setEditingMovie(m);
    setMovieForm({
      title: m.title,
      description: m.description,
      genre: m.genre.join(', '),
      duration: m.duration,
      rating: m.rating,
      imdbRating: m.imdbRating,
      releaseDate: m.releaseDate,
      posterUrl: m.posterUrl,
      director: m.director,
      cast: m.cast.join(', '),
      language: m.language,
      status: m.status,
      featured: m.featured,
    });
    setShowMovieModal(true);
  };

  const handleSaveMovie = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingMovie) {
        await api.updateMovie(editingMovie._id, movieForm as any);
        setNotice({ type: 'success', text: `Movie "${movieForm.title}" updated successfully.` });
      } else {
        await api.createMovie(movieForm as any);
        setNotice({ type: 'success', text: `Movie "${movieForm.title}" added to catalog.` });
      }
      setShowMovieModal(false);
      await refreshMovies();
      await loadData();
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Failed to save movie.' });
    }
  };

  const handleDeleteMovie = async (movieId: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete "${title}"? This will also remove all its scheduled showtimes.`)) return;

    try {
      await api.deleteMovie(movieId);
      setNotice({ type: 'success', text: `Movie "${title}" deleted.` });
      await refreshMovies();
      await loadData();
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Failed to delete movie.' });
    }
  };

  // Showtime actions
  const handleCreateShowtime = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createShowtime(showtimeForm);
      setNotice({ type: 'success', text: 'Showtime scheduled successfully.' });
      setShowShowtimeModal(false);
      await loadData();
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Failed to schedule showtime.' });
    }
  };

  const handleDeleteShowtime = async (id: string) => {
    if (!window.confirm('Delete this showtime?')) return;
    try {
      await api.deleteShowtime(id);
      setNotice({ type: 'success', text: 'Showtime removed.' });
      await loadData();
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Failed to delete showtime.' });
    }
  };

  // Booking cancel action
  const handleCancelBooking = async (id: string) => {
    if (!window.confirm('Cancel this booking and release seats back to the hall?')) return;
    try {
      await api.cancelBooking(id);
      setNotice({ type: 'success', text: 'Booking cancelled and seats freed up.' });
      await loadData();
    } catch (err: any) {
      setNotice({ type: 'error', text: err.message || 'Failed to cancel booking.' });
    }
  };

  const filteredBookings = allBookings.filter(
    (b) =>
      b.bookingNumber.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.customerName.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.customerEmail.toLowerCase().includes(bookingSearch.toLowerCase()) ||
      b.movieTitle.toLowerCase().includes(bookingSearch.toLowerCase())
  );

  return (
    <div className="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800 mb-8">
        <div>
          <button
            onClick={onBackToMovies}
            className="text-xs text-amber-400 hover:text-amber-300 font-semibold mb-2 block cursor-pointer"
          >
            ← Back to Cinema Storefront
          </button>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
              Cinema Admin Console
            </h1>
            <span className="text-[10px] font-mono-num font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 uppercase">
              Full Privileges
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time management for movies, showtimes, seats concurrency, and revenue audits.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'analytics' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Analytics</span>
          </button>
          <button
            onClick={() => setActiveTab('movies')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'movies' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Movies ({movies.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('showtimes')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'showtimes' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Showtimes ({showtimes.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('bookings')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'bookings' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Ticket className="w-3.5 h-3.5" />
            <span>All Bookings ({allBookings.length})</span>
          </button>
        </div>
      </div>

      {/* Notice Banner */}
      {notice && (
        <div
          className={`mb-6 p-3.5 rounded-xl text-xs flex items-center justify-between border ${
            notice.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{notice.text}</span>
          </div>
          <button onClick={() => setNotice(null)} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TAB 1: ANALYTICS */}
      {activeTab === 'analytics' && (
        <div className="space-y-8">
          {/* Key Metrics Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Total Cinema Revenue
              </span>
              <p className="text-2xl font-extrabold text-white font-mono-num">
                ₹{stats?.totalRevenue ? stats.totalRevenue.toLocaleString() : '0'}
              </p>
              <span className="text-[11px] text-emerald-400 font-mono-num mt-1 block">Live Concurrency Sync</span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Confirmed Bookings
              </span>
              <p className="text-2xl font-extrabold text-white font-mono-num">{stats?.totalBookings || 0}</p>
              <span className="text-[11px] text-slate-400 font-mono-num mt-1 block">
                {stats?.totalTicketsSold || 0} Total Seats Reserved
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Average Hall Occupancy
              </span>
              <p className="text-2xl font-extrabold text-amber-400 font-mono-num">
                {stats?.averageOccupancy || '0.0%'}
              </p>
              <span className="text-[11px] text-slate-400 font-mono-num mt-1 block">Across Screens 1, 2, and 3</span>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Active Catalog Movies
              </span>
              <p className="text-2xl font-extrabold text-white font-mono-num">{stats?.activeMovies || 0}</p>
              <span className="text-[11px] text-slate-400 font-mono-num mt-1 block">
                {stats?.totalShowtimes || 0} Weekly Showtimes
              </span>
            </div>
          </div>

          {/* Quick Management Shortcuts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800">
              <h3 className="text-base font-bold text-white mb-2 font-display">Manage Movie Titles</h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                Add upcoming blockbusters, modify descriptions, release dates, durations, or cinema poster artwork.
              </p>
              <button
                onClick={handleOpenAddMovie}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add New Movie</span>
              </button>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900/50 border border-slate-800">
              <h3 className="text-base font-bold text-white mb-2 font-display">Schedule Hall Showtimes</h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                Slot movies into Screen 1 (IMAX), Screen 2 (VIP Suite), or Screen 3 (4DX) with custom seat pricing.
              </p>
              <button
                onClick={() => setShowShowtimeModal(true)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>Schedule Showtime</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MOVIES */}
      {activeTab === 'movies' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white font-display">All Cinema Movies</h3>
            <button
              onClick={handleOpenAddMovie}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Movie</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-mono-num text-[10px]">
                <tr>
                  <th className="py-3 px-4">Poster</th>
                  <th className="py-3 px-4">Title & Details</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4">Rating</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {movies.map((m) => (
                  <tr key={m._id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="w-10 h-14 rounded-lg overflow-hidden bg-slate-950 border border-slate-800">
                        <img
                          src={m.posterUrl}
                          alt={m.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-white text-sm">{m.title}</p>
                      <p className="text-[11px] text-slate-400">{m.genre.join(', ')}</p>
                    </td>
                    <td className="py-3 px-4 font-mono-num">{m.duration} mins</td>
                    <td className="py-3 px-4 font-mono-num">
                      <span className="text-amber-400 font-bold">{m.imdbRating}</span> / 10
                    </td>
                    <td className="py-3 px-4 font-mono-num">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          m.status === 'now_showing'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/30'
                        }`}
                      >
                        {m.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEditMovie(m)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteMovie(m._id, m.title)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SHOWTIMES */}
      {activeTab === 'showtimes' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-white font-display">Scheduled Showtimes</h3>
            <button
              onClick={() => setShowShowtimeModal(true)}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Schedule Showtime</span>
            </button>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-mono-num text-[10px]">
                <tr>
                  <th className="py-3 px-4">Movie</th>
                  <th className="py-3 px-4">Auditorium / Hall</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Pricing (S/G/P)</th>
                  <th className="py-3 px-4">Booked / Total</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {showtimes.map((st) => {
                  const movie = typeof st.movieId === 'object' ? (st.movieId as Movie) : movies.find((m) => m._id === st.movieId);
                  return (
                    <tr key={st._id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-bold text-white">{movie?.title || 'Unknown Film'}</td>
                      <td className="py-3 px-4">
                        <span className="text-slate-200 block">{st.cinemaHall}</span>
                        <span className="text-[10px] text-amber-400 font-mono-num">{st.format}</span>
                      </td>
                      <td className="py-3 px-4 font-mono-num">
                        {st.date} at <span className="font-bold text-white">{st.time}</span>
                      </td>
                      <td className="py-3 px-4 font-mono-num text-slate-400">
                        ₹{st.pricing.silver} / ₹{st.pricing.gold} / ₹{st.pricing.platinum}
                      </td>
                      <td className="py-3 px-4 font-mono-num">
                        <span className="text-amber-400 font-bold">{st.bookedSeats?.length || 0}</span> / {st.totalSeats || 64}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => handleDeleteShowtime(st._id)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: ALL BOOKINGS */}
      {activeTab === 'bookings' && (
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <h3 className="text-base font-bold text-white font-display">Customer Bookings & Concurrency Log</h3>
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search booking ID, customer or movie..."
                value={bookingSearch}
                onChange={(e) => setBookingSearch(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/60">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-mono-num text-[10px]">
                <tr>
                  <th className="py-3 px-4">Ref #</th>
                  <th className="py-3 px-4">Movie & Hall</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Show Details</th>
                  <th className="py-3 px-4">Seats</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {filteredBookings.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      No matching bookings found.
                    </td>
                  </tr>
                ) : (
                  filteredBookings.map((b) => (
                    <tr key={b._id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-amber-400">{b.bookingNumber}</td>
                      <td className="py-3 px-4">
                        <p className="font-semibold text-white">{b.movieTitle}</p>
                        <p className="text-[11px] text-slate-400">{b.cinemaHall}</p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="font-medium text-slate-200">{b.customerName}</p>
                        <p className="text-[11px] text-slate-500">{b.customerEmail}</p>
                      </td>
                      <td className="py-3 px-4 font-mono-num">
                        {b.showDate} · {b.showTime}
                      </td>
                      <td className="py-3 px-4 font-mono-num font-bold text-amber-300">
                        {b.seats.map((s) => s.seatNumber).join(', ')}
                      </td>
                      <td className="py-3 px-4 font-mono-num font-bold text-white">₹{b.grandTotal.toFixed(2)}</td>
                      <td className="py-3 px-4 font-mono-num">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] uppercase font-semibold ${
                            b.bookingStatus === 'confirmed'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {b.bookingStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {b.bookingStatus === 'confirmed' && (
                          <button
                            onClick={() => handleCancelBooking(b._id)}
                            className="px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-[11px] font-semibold cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT MOVIE */}
      {showMovieModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-[#0d121f] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-6">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
              <h3 className="text-sm font-bold text-white font-display">
                {editingMovie ? 'Edit Cinema Movie' : 'Add New Movie to IMovies'}
              </h3>
              <button
                onClick={() => setShowMovieModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMovie} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Movie Title</label>
                  <input
                    type="text"
                    required
                    value={movieForm.title}
                    onChange={(e) => setMovieForm({ ...movieForm, title: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                    placeholder="e.g. Interstellar Odyssey"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Synopsis / Description</label>
                  <textarea
                    required
                    rows={3}
                    value={movieForm.description}
                    onChange={(e) => setMovieForm({ ...movieForm, description: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Genres (comma separated)</label>
                  <input
                    type="text"
                    value={movieForm.genre}
                    onChange={(e) => setMovieForm({ ...movieForm, genre: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Duration (minutes)</label>
                  <input
                    type="number"
                    value={movieForm.duration}
                    onChange={(e) => setMovieForm({ ...movieForm, duration: parseInt(e.target.value, 10) || 120 })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Age Rating</label>
                  <select
                    value={movieForm.rating}
                    onChange={(e) => setMovieForm({ ...movieForm, rating: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="U">U (Universal)</option>
                    <option value="UA 13+">UA 13+</option>
                    <option value="UA 16+">UA 16+</option>
                    <option value="PG-13">PG-13</option>
                    <option value="R">R (Adults 18+)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">IMDb Rating (out of 10)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="10"
                    value={movieForm.imdbRating}
                    onChange={(e) => setMovieForm({ ...movieForm, imdbRating: parseFloat(e.target.value) || 8.0 })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Catalog Status</label>
                  <select
                    value={movieForm.status}
                    onChange={(e) => setMovieForm({ ...movieForm, status: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="now_showing">Now Showing</option>
                    <option value="coming_soon">Coming Soon</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Director</label>
                  <input
                    type="text"
                    value={movieForm.director}
                    onChange={(e) => setMovieForm({ ...movieForm, director: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Poster Selector */}
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Poster Artwork URL</label>
                  <input
                    type="text"
                    required
                    value={movieForm.posterUrl}
                    onChange={(e) => setMovieForm({ ...movieForm, posterUrl: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400 mb-2"
                  />
                  {/* Preset Quick Poster Buttons */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-500 uppercase">Preset Cinema Artworks:</span>
                    {[
                      { label: 'Space', url: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg' },
                      { label: 'Noir', url: '/src/assets/images/poster_crimson_shadows_1793091325938.jpg' },
                      { label: 'Cyber', url: '/src/assets/images/poster_cyber_nexus_1793091326294.jpg' },
                      { label: 'Fantasy', url: '/src/assets/images/poster_enchanted_kingdom_1793091326406.jpg' },
                    ].map((p) => (
                      <button
                        type="button"
                        key={p.label}
                        onClick={() => setMovieForm({ ...movieForm, posterUrl: p.url })}
                        className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-amber-400 hover:bg-slate-700 cursor-pointer"
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowMovieModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl cursor-pointer shadow-md shadow-amber-400/20"
                >
                  {editingMovie ? 'Save Changes' : 'Create Movie'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SCHEDULE SHOWTIME */}
      {showShowtimeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-[#0d121f] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-6">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/60">
              <h3 className="text-sm font-bold text-white font-display">Schedule Auditorium Showtime</h3>
              <button
                onClick={() => setShowShowtimeModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateShowtime} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Select Movie</label>
                <select
                  required
                  value={showtimeForm.movieId}
                  onChange={(e) => setShowtimeForm({ ...showtimeForm, movieId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  {movies.map((m) => (
                    <option key={m._id} value={m._id}>
                      {m.title} ({m.rating})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Auditorium Screen</label>
                <select
                  value={showtimeForm.cinemaHall}
                  onChange={(e) => {
                    const hall = e.target.value;
                    let fmt = 'Dolby Atmos 2D';
                    let p = { silver: 220, gold: 350, platinum: 520 };
                    if (hall.includes('IMAX')) {
                      fmt = 'IMAX 3D';
                      p = { silver: 280, gold: 420, platinum: 600 };
                    } else if (hall.includes('VIP')) {
                      fmt = 'VIP Luxe';
                      p = { silver: 350, gold: 500, platinum: 750 };
                    } else if (hall.includes('4DX')) {
                      fmt = '4DX';
                      p = { silver: 300, gold: 450, platinum: 620 };
                    }
                    setShowtimeForm({
                      ...showtimeForm,
                      cinemaHall: hall,
                      format: fmt,
                      pricing: p,
                    });
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                >
                  <option value="Screen 1 – IMAX Laser & Dolby Atmos">Screen 1 – IMAX Laser & Dolby Atmos</option>
                  <option value="Screen 2 – VIP Luxe Recliner Suite">Screen 2 – VIP Luxe Recliner Suite</option>
                  <option value="Screen 3 – 4DX Dynamic Motion">Screen 3 – 4DX Dynamic Motion</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={showtimeForm.date}
                    onChange={(e) => setShowtimeForm({ ...showtimeForm, date: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Showtime</label>
                  <input
                    type="text"
                    required
                    value={showtimeForm.time}
                    onChange={(e) => setShowtimeForm({ ...showtimeForm, time: e.target.value })}
                    placeholder="e.g. 07:30 PM"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Tier Pricing (₹)</label>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Silver</span>
                    <input
                      type="number"
                      value={showtimeForm.pricing.silver}
                      onChange={(e) =>
                        setShowtimeForm({
                          ...showtimeForm,
                          pricing: { ...showtimeForm.pricing, silver: parseInt(e.target.value, 10) || 0 },
                        })
                      }
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Gold</span>
                    <input
                      type="number"
                      value={showtimeForm.pricing.gold}
                      onChange={(e) =>
                        setShowtimeForm({
                          ...showtimeForm,
                          pricing: { ...showtimeForm.pricing, gold: parseInt(e.target.value, 10) || 0 },
                        })
                      }
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">Platinum</span>
                    <input
                      type="number"
                      value={showtimeForm.pricing.platinum}
                      onChange={(e) =>
                        setShowtimeForm({
                          ...showtimeForm,
                          pricing: { ...showtimeForm.pricing, platinum: parseInt(e.target.value, 10) || 0 },
                        })
                      }
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowShowtimeModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl cursor-pointer shadow-md shadow-amber-400/20"
                >
                  Schedule Show
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

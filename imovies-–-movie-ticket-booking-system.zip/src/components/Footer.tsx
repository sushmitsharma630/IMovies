import React from 'react';
import { Film, ShieldCheck, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-slate-800/80 bg-[#06080e] text-slate-400 py-12 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800/60">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-400 flex items-center justify-center text-slate-950 font-bold">
                <Film className="w-3.5 h-3.5" />
              </div>
              <span className="font-display font-extrabold text-white text-base tracking-wider uppercase">
                I<span className="text-amber-400">Movies</span> Cinemas
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Next-generation cinema ticket reservation system engineered with MERN stack (MongoDB, Express, React, Node.js) featuring high-concurrency atomic seat reservation locks and instant digital boarding passes.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-mono-num">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Full-Stack MERN Architecture · College Capstone Project</span>
            </div>
          </div>

          {/* Cinema Screens */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-white uppercase tracking-wider font-display">Cinemas & Halls</p>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>Screen 1: IMAX Laser & Dolby Atmos</li>
              <li>Screen 2: VIP Luxe Recliner Suite</li>
              <li>Screen 3: 4DX Dynamic Motion</li>
              <li>Dolby Surround 7.1 Multi-Auditoriums</li>
            </ul>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-white uppercase tracking-wider font-display">Cinema Experience</p>
            <ul className="space-y-1.5 text-xs text-slate-400">
              <li>Now Showing Releases</li>
              <li>Coming Soon Catalog</li>
              <li>Gourmet Concessions & Dining</li>
              <li>VIP Private Screen Bookings</li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} IMovies – Movie Ticket Booking System. All Rights Reserved.</p>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Crafted with</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
            <span>for College Project Demonstration</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

import React, { useState, useEffect } from 'react';
import { Booking } from '../types/index.ts';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { Ticket, Calendar, Clock, Armchair, AlertCircle, Loader2, ArrowLeft, Ban } from 'lucide-react';

interface MyBookingsViewProps {
  onBackToMovies: () => void;
  onViewTicket: (booking: Booking) => void;
}

export const MyBookingsView: React.FC<MyBookingsViewProps> = ({ onBackToMovies, onViewTicket }) => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadBookings = async () => {
    setIsLoading(true);
    try {
      const res = await api.getMyBookings();
      setBookings(res.bookings || []);
    } catch (err: any) {
      console.error('Failed to load user bookings', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const handleCancel = async (bookingId: string) => {
    const confirmCancel = window.confirm(
      'Are you sure you want to cancel this booking? The reserved seats will be immediately released back to other customers.'
    );
    if (!confirmCancel) return;

    setCancellingId(bookingId);
    setFeedbackMsg(null);

    try {
      await api.cancelBooking(bookingId);
      setFeedbackMsg({ type: 'success', text: 'Booking successfully cancelled and seats released.' });
      await loadBookings();
    } catch (err: any) {
      setFeedbackMsg({ type: 'error', text: err.message || 'Failed to cancel ticket.' });
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="py-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Top Breadcrumb & Heading */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800 mb-8">
        <div>
          <button
            onClick={onBackToMovies}
            className="flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 transition-colors mb-2 cursor-pointer font-semibold"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Cinema Shows</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-display">My Cinema Bookings</h1>
          <p className="text-xs text-slate-400 mt-1">
            Logged in as <span className="text-slate-200 font-medium">{user?.email}</span>
          </p>
        </div>

        <button
          onClick={loadBookings}
          className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer self-start sm:self-auto"
        >
          Refresh Feed
        </button>
      </div>

      {feedbackMsg && (
        <div
          className={`mb-6 p-3.5 rounded-xl text-xs flex items-center gap-2 border ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3 text-slate-400">
          <Loader2 className="w-6 h-6 animate-spin text-amber-400" />
          <span className="text-xs">Fetching your ticket history...</span>
        </div>
      ) : bookings.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/40 border border-slate-800 rounded-2xl">
          <Ticket className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-300">No tickets booked yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Choose a movie from our catalog, pick your preferred seats, and your confirmed tickets will appear here!
          </p>
          <button
            onClick={onBackToMovies}
            className="mt-6 px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition-all cursor-pointer shadow-md shadow-amber-400/20"
          >
            Explore Movies Now
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <div
              key={booking._id}
              className={`p-5 rounded-2xl border transition-all bg-slate-900/70 ${
                booking.bookingStatus === 'confirmed'
                  ? 'border-slate-800 hover:border-slate-700'
                  : 'border-slate-800/50 opacity-70'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold text-amber-400 tracking-wider">
                      {booking.bookingNumber}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span
                      className={`text-[10px] font-mono-num uppercase font-semibold px-2 py-0.5 rounded ${
                        booking.bookingStatus === 'confirmed'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {booking.bookingStatus}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white font-display">{booking.movieTitle}</h3>
                  <p className="text-xs text-slate-400 mt-0.5">{booking.cinemaHall}</p>
                </div>

                <div className="text-left sm:text-right font-mono-num">
                  <span className="text-[10px] text-slate-500 uppercase block">Grand Total</span>
                  <span className="text-base font-bold text-white">₹{booking.grandTotal.toFixed(2)}</span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">Paid via {booking.paymentMethod}</span>
                </div>
              </div>

              {/* Show info & seats */}
              <div className="py-3 flex flex-wrap items-center justify-between gap-4 text-xs font-mono-num text-slate-300">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>{booking.showDate}</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>{booking.showTime}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-300">
                    <Armchair className="w-3.5 h-3.5" />
                    <span>Seats: {booking.seats.map((s) => s.seatNumber).join(', ')}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onViewTicket(booking)}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors cursor-pointer"
                  >
                    View E-Ticket
                  </button>

                  {booking.bookingStatus === 'confirmed' && (
                    <button
                      disabled={cancellingId === booking._id}
                      onClick={() => handleCancel(booking._id)}
                      className="px-3.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50"
                    >
                      <Ban className="w-3 h-3" />
                      <span>{cancellingId === booking._id ? 'Cancelling...' : 'Cancel'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Sparkles, Armchair, Volume2, Film, ShieldCheck } from 'lucide-react';

export const ExperienceSection: React.FC = () => {
  const experiences = [
    {
      title: 'IMAX Laser 3D',
      desc: 'Next-generation 4K dual laser projection system with monumental screen geometry and precision tuned digital acoustics.',
      icon: Film,
      highlight: 'Screen 1',
    },
    {
      title: 'Dolby Atmos Sound',
      desc: 'Multidimensional sound that flows all around you with 64 individual acoustic speaker channels for total immersion.',
      icon: Volume2,
      highlight: 'Screen 1 & 2',
    },
    {
      title: 'Luxe VIP Recliners',
      desc: 'Handcrafted premium leather recliners with motorized footrests, swivel dining tables, and warm blanket service.',
      icon: Armchair,
      highlight: 'VIP Suite',
    },
    {
      title: 'Atomic Safe Booking',
      desc: 'High-concurrency seat reservation engine preventing duplicate bookings with immediate digital e-ticket delivery.',
      icon: ShieldCheck,
      highlight: 'Instant QR',
    },
  ];

  return (
    <section id="experience-section" className="py-16 bg-[#0a0f1c] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-amber-400 uppercase tracking-widest mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>THE IMOVIES CINEMATIC STANDARD</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white font-display tracking-tight">
            Crafted for True Film Connoisseurs
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-2">
            State-of-the-art cinematic technology engineered to deliver visceral, unforgettable audiovisual storytelling.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {experiences.map((exp, idx) => {
            const Icon = exp.icon;
            return (
              <div
                key={idx}
                className="bg-slate-900/60 border border-slate-800/90 rounded-2xl p-6 transition-all hover:border-amber-500/40 hover:bg-slate-900"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[11px] font-mono-num text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
                    {exp.highlight}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mb-2 font-display">{exp.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{exp.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { Booking } from '../types/index.ts';
import { X, CheckCircle, Printer, Download, Film, QrCode, ShieldCheck } from 'lucide-react';

interface TicketModalProps {
  booking: Booking | null;
  onClose: () => void;
}

export const TicketModal: React.FC<TicketModalProps> = ({ booking, onClose }) => {
  if (!booking) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-[#0c101c] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl my-6">
        {/* Header with Close */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800/80 bg-slate-900/40">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
            <CheckCircle className="w-4 h-4" />
            <span>Booking Confirmed & Verified</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Ticket Pass Container */}
        <div id="printable-ticket" className="p-6">
          <div className="relative bg-gradient-to-b from-[#131b2e] to-[#0d1322] border border-slate-700/80 rounded-2xl p-6 shadow-xl overflow-hidden">
            {/* Top Pass Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-700/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400 flex items-center justify-center text-slate-950 font-bold">
                  <Film className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-extrabold tracking-wider text-white uppercase font-display">
                    IMOVIES <span className="text-amber-400">TICKET</span>
                  </span>
                  <p className="text-[10px] text-slate-400 font-mono-num">REF: {booking.bookingNumber}</p>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-mono-num uppercase font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  {booking.bookingStatus}
                </span>
                <p className="text-[10px] text-slate-400 mt-0.5">{booking.format}</p>
              </div>
            </div>

            {/* Movie Title & Hall */}
            <div className="py-4">
              <h3 className="text-xl font-extrabold text-white font-display tracking-tight leading-snug">
                {booking.movieTitle}
              </h3>
              <p className="text-xs text-amber-400 font-medium mt-1">{booking.cinemaHall}</p>
            </div>

            {/* Ticket Data Grid */}
            <div className="grid grid-cols-2 gap-3 py-3 border-y border-dashed border-slate-700/70 text-xs font-mono-num">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Date & Time</span>
                <span className="text-slate-200 font-semibold">
                  {booking.showDate} · {booking.showTime}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Auditorium Screen</span>
                <span className="text-slate-200 font-semibold">{booking.cinemaHall.split('–')[0]}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Reserved Seats</span>
                <span className="text-amber-400 font-bold text-sm">
                  {booking.seats.map((s) => s.seatNumber).join(', ')}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block uppercase">Total Amount Paid</span>
                <span className="text-white font-bold text-sm">₹{booking.grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Customer Details */}
            <div className="pt-3 text-[11px] text-slate-400 flex items-center justify-between">
              <div>
                <span className="text-slate-500">Guest:</span> <span className="text-slate-300 font-medium">{booking.customerName}</span>
              </div>
              <div>
                <span className="text-slate-500">Payment:</span> <span className="text-slate-300 font-medium">{booking.paymentMethod}</span>
              </div>
            </div>

            {/* Simulated QR Code / Barcode Scanner Strip */}
            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between gap-4 bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold font-mono-num">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Verified Admission Pass</span>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight">
                  Scan this pass at screen entry gate. No physical paper printing required.
                </p>
              </div>

              {/* QR Graphic */}
              <div className="w-14 h-14 bg-white p-1 rounded-lg shrink-0 flex items-center justify-center shadow-md">
                <QrCode className="w-full h-full text-slate-950" />
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 pb-6 pt-2 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Done
          </button>

          <button
            onClick={handlePrint}
            className="px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 transition-colors flex items-center gap-2 cursor-pointer shadow-md shadow-amber-400/20"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save Ticket</span>
          </button>
        </div>
      </div>
    </div>
  );
};

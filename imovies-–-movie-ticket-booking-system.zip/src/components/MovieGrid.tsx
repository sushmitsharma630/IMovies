import React, { useState, useMemo } from 'react';
import { Movie } from '../types/index.ts';
import { Search, Star, Clock, Calendar, Ticket, Film, SlidersHorizontal } from 'lucide-react';

interface MovieGridProps {
  movies: Movie[];
  onSelectMovie: (movie: Movie) => void;
  isLoading: boolean;
}

const GENRES = ['All', 'Sci-Fi', 'Action', 'Thriller', 'Fantasy', 'Adventure', 'Crime'];

export const MovieGrid: React.FC<MovieGridProps> = ({ movies, onSelectMovie, isLoading }) => {
  const [activeStatus, setActiveStatus] = useState<'now_showing' | 'coming_soon'>('now_showing');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredMovies = useMemo(() => {
    return movies.filter((m) => {
      const matchesStatus = m.status === activeStatus;
      const matchesGenre =
        selectedGenre === 'All' ||
        m.genre.some((g) => g.toLowerCase() === selectedGenre.toLowerCase());
      const matchesSearch =
        searchQuery === '' ||
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.director.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.genre.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesStatus && matchesGenre && matchesSearch;
    });
  }, [movies, activeStatus, selectedGenre, searchQuery]);

  return (
    <section id="now-showing-section" className="py-12 bg-[#080b12]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800/80 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 tracking-wider uppercase mb-1">
              <span>EXPLORE MOVIES & SHOWS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight font-display">
              Cinema Catalog & Showtimes
            </h2>
          </div>

          {/* Status Tabs: Now Showing vs Coming Soon */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl shrink-0">
            <button
              onClick={() => setActiveStatus('now_showing')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeStatus === 'now_showing'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Now Showing ({movies.filter((m) => m.status === 'now_showing').length})
            </button>
            <button
              onClick={() => setActiveStatus('coming_soon')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                activeStatus === 'coming_soon'
                  ? 'bg-amber-400 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Coming Soon ({movies.filter((m) => m.status === 'coming_soon').length})
            </button>
          </div>
        </div>

        {/* Filter & Search Toolbar */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8">
          {/* Genre Segmented Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {GENRES.map((genre) => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedGenre === genre
                    ? 'bg-slate-800 text-amber-400 border border-amber-500/30'
                    : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800/60'
                }`}
              >
                {genre}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search movie title, director, or genre..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400/80 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Movies Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse bg-slate-900 rounded-2xl h-[420px] border border-slate-800" />
            ))}
          </div>
        ) : filteredMovies.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/30 border border-slate-800 rounded-2xl">
            <Film className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <p className="text-base font-semibold text-slate-300">No movies found</p>
            <p className="text-xs text-slate-500 mt-1">Try adjusting your search criteria or genre filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredMovies.map((movie) => (
              <div
                key={movie._id}
                className="group flex flex-col bg-slate-900/80 border border-slate-800/90 rounded-2xl overflow-hidden hover:border-slate-700 transition-all duration-300 hover:shadow-xl hover:shadow-black/50"
              >
                {/* Poster Container */}
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-slate-950">
                  <img
                    src={movie.posterUrl}
                    alt={movie.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />

                  {/* Gradient bottom scrim */}
                  <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

                  {/* Rating badge & language in image */}
                  <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-xs font-mono-num text-white">
                    <div className="flex items-center gap-1 bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded-md border border-slate-700/60">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span className="font-bold text-amber-300">{movie.imdbRating.toFixed(1)}</span>
                    </div>
                    <span className="text-slate-300 bg-slate-950/80 backdrop-blur-md px-2 py-1 rounded-md border border-slate-700/60 text-[11px]">
                      {movie.rating}
                    </span>
                  </div>
                </div>

                {/* Card Info Content */}
                <div className="p-4 flex flex-col flex-1 justify-between">
                  <div>
                    {/* Unboxed Metadata with · separator */}
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mb-1.5">
                      <span>{movie.genre.slice(0, 2).join(' / ')}</span>
                      <span aria-hidden="true">·</span>
                      <span className="flex items-center gap-1 font-mono-num">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {movie.duration}m
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1 mb-2 font-display">
                      {movie.title}
                    </h3>

                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4">
                      {movie.description}
                    </p>
                  </div>

                  {/* Bottom Action Area */}
                  <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <div className="text-[11px] text-slate-400 font-mono-num">
                      <span className="text-slate-500 block text-[10px]">TICKETS FROM</span>
                      <span className="text-amber-400 font-semibold text-xs">₹220</span>
                    </div>

                    <button
                      onClick={() => onSelectMovie(movie)}
                      className="px-3.5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shrink-0 shadow-sm"
                    >
                      <Ticket className="w-3.5 h-3.5" />
                      <span>{movie.status === 'now_showing' ? 'Book Seats' : 'View Details'}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Movie, Showtime, BookedSeatItem, Booking } from './types/index.ts';
import { api } from './services/api.ts';
import { Navbar } from './components/Navbar.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { MovieGrid } from './components/MovieGrid.tsx';
import { ExperienceSection } from './components/ExperienceSection.tsx';
import { MovieDetailsModal } from './components/MovieDetailsModal.tsx';
import { SeatSelectorModal } from './components/SeatSelectorModal.tsx';
import { CheckoutModal } from './components/CheckoutModal.tsx';
import { TicketModal } from './components/TicketModal.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { MyBookingsView } from './components/MyBookingsView.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { Footer } from './components/Footer.tsx';

function MainApp() {
  const { user } = useAuth();

  // Navigation tab: 'home' | 'my-bookings' | 'admin'
  const [activeTab, setActiveTab] = useState<'home' | 'my-bookings' | 'admin'>('home');

  // Movies list
  const [movies, setMovies] = useState<Movie[]>([]);
  const [isLoadingMovies, setIsLoadingMovies] = useState(true);

  // Modals state
  const [detailsMovie, setDetailsMovie] = useState<Movie | null>(null);
  const [bookingMovie, setBookingMovie] = useState<Movie | null>(null);
  const [activeShowtime, setActiveShowtime] = useState<Showtime | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<BookedSeatItem[]>([]);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const fetchMovies = async () => {
    setIsLoadingMovies(true);
    try {
      const res = await api.getMovies();
      setMovies(res.movies || []);
    } catch (err) {
      console.error('Failed to load movies', err);
    } finally {
      setIsLoadingMovies(false);
    }
  };

  useEffect(() => {
    fetchMovies();
  }, []);

  // When user selects a movie from grid or hero banner
  const handleSelectMovie = (movie: Movie) => {
    setDetailsMovie(movie);
  };

  // When user picks a showtime from MovieDetailsModal
  const handleSelectShowtime = (showtime: Showtime, movie: Movie) => {
    setDetailsMovie(null);
    setBookingMovie(movie);
    setActiveShowtime(showtime);
  };

  // When user finishes seat selection and proceeds to checkout
  const handleProceedToCheckout = (seats: BookedSeatItem[], showtime: Showtime, movie: Movie) => {
    setSelectedSeats(seats);
    setActiveShowtime(showtime);
    setBookingMovie(movie);
    setIsCheckoutOpen(true);
  };

  // When booking succeeds
  const handleBookingSuccess = (booking: Booking) => {
    setIsCheckoutOpen(false);
    setActiveShowtime(null);
    setBookingMovie(null);
    setSelectedSeats([]);
    setConfirmedBooking(booking);
    fetchMovies(); // Refresh showtimes/seat counts
  };

  const featuredMovie = movies.find((m) => m.featured) || movies[0];

  return (
    <div className="min-h-screen bg-[#080b12] text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab: string) => setActiveTab(tab as any)}
        openAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            {/* Cinema Spotlight Hero */}
            <HeroBanner
              movie={featuredMovie}
              onSelectMovie={handleSelectMovie}
              onExploreClick={() => {
                const el = document.getElementById('now-showing-section');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Catalog & Showtimes Grid */}
            <MovieGrid
              movies={movies}
              onSelectMovie={handleSelectMovie}
              isLoading={isLoadingMovies}
            />

            {/* Cinema Standards Showcase */}
            <ExperienceSection />
          </>
        )}

        {activeTab === 'my-bookings' && (
          <MyBookingsView
            onBackToMovies={() => setActiveTab('home')}
            onViewTicket={(booking) => setConfirmedBooking(booking)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            onBackToMovies={() => setActiveTab('home')}
            movies={movies}
            refreshMovies={fetchMovies}
          />
        )}
      </main>

      {/* Cinema Footer */}
      <Footer />

      {/* MODALS */}

      {/* 1. Movie Details & Showtime Selection Modal */}
      {detailsMovie && (
        <MovieDetailsModal
          movie={detailsMovie}
          onClose={() => setDetailsMovie(null)}
          onSelectShowtime={handleSelectShowtime}
        />
      )}

      {/* 2. Interactive Seat Selector Modal */}
      {activeShowtime && bookingMovie && !isCheckoutOpen && (
        <SeatSelectorModal
          movie={bookingMovie}
          showtime={activeShowtime}
          onClose={() => {
            setActiveShowtime(null);
            setBookingMovie(null);
          }}
          onProceedToCheckout={handleProceedToCheckout}
        />
      )}

      {/* 3. Secure Checkout Modal */}
      {isCheckoutOpen && activeShowtime && bookingMovie && (
        <CheckoutModal
          movie={bookingMovie}
          showtime={activeShowtime}
          selectedSeats={selectedSeats}
          onClose={() => setIsCheckoutOpen(false)}
          onBookingSuccess={handleBookingSuccess}
          openAuthModal={() => setIsAuthModalOpen(true)}
        />
      )}

      {/* 4. Digital Boarding Pass Ticket Modal */}
      {confirmedBooking && (
        <TicketModal
          booking={confirmedBooking}
          onClose={() => setConfirmedBooking(null)}
        />
      )}

      {/* 5. User & Admin Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  phone?: string;
}

export interface Movie {
  _id: string;
  title: string;
  description: string;
  genre: string[];
  duration: number; // minutes
  rating: string;
  imdbRating: number;
  releaseDate: string;
  posterUrl: string;
  bannerUrl?: string;
  trailerUrl?: string;
  director: string;
  cast: string[];
  language: string;
  status: 'now_showing' | 'coming_soon';
  featured: boolean;
}

export interface ShowtimePricing {
  silver: number;
  gold: number;
  platinum: number;
}

export interface Showtime {
  _id: string;
  movieId: string | Movie;
  cinemaHall: string;
  date: string;
  time: string;
  format: string;
  pricing: ShowtimePricing;
  bookedSeats: string[];
  totalSeats: number;
}

export interface BookedSeatItem {
  seatNumber: string;
  tier: 'silver' | 'gold' | 'platinum';
  price: number;
}

export interface Booking {
  _id: string;
  bookingNumber: string;
  userId: string;
  showtimeId: string;
  movieId: string;
  movieTitle: string;
  moviePoster: string;
  cinemaHall: string;
  showDate: string;
  showTime: string;
  format: string;
  seats: BookedSeatItem[];
  subtotal: number;
  convenienceFee: number;
  taxAmount: number;
  grandTotal: number;
  paymentMethod: string;
  paymentStatus: 'completed' | 'pending' | 'cancelled';
  bookingStatus: 'confirmed' | 'cancelled';
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  createdAt: string;
}

export interface CinemaStats {
  totalRevenue: number;
  totalBookings: number;
  totalTicketsSold: number;
  totalMovies: number;
  activeMovies: number;
  totalShowtimes: number;
  averageOccupancy: string;
}

import { Movie, Showtime, Booking, CinemaStats, User } from '../types/index.ts';

const API_BASE = '/api';

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('imovies_token');
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

async function handleResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Request failed with status ${res.status}`);
  }
  return data;
}

export const api = {
  // Auth
  async login(credentials: { email: string; password: string }): Promise<{ token: string; user: User }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials),
    });
    return handleResponse(res);
  },

  async register(payload: { name: string; email: string; password: string; phone?: string; role?: string }): Promise<{ token: string; user: User }> {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  async getMe(): Promise<{ user: User }> {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Movies
  async getMovies(params?: { search?: string; genre?: string; status?: string }): Promise<{ movies: Movie[] }> {
    const query = new URLSearchParams();
    if (params?.search) query.append('search', params.search);
    if (params?.genre) query.append('genre', params.genre);
    if (params?.status) query.append('status', params.status);

    const res = await fetch(`${API_BASE}/movies?${query.toString()}`);
    return handleResponse(res);
  },

  async getMovie(id: string): Promise<{ movie: Movie }> {
    const res = await fetch(`${API_BASE}/movies/${id}`);
    return handleResponse(res);
  },

  async createMovie(movieData: Partial<Movie>): Promise<{ movie: Movie; message: string }> {
    const res = await fetch(`${API_BASE}/movies`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(movieData),
    });
    return handleResponse(res);
  },

  async updateMovie(id: string, movieData: Partial<Movie>): Promise<{ movie: Movie; message: string }> {
    const res = await fetch(`${API_BASE}/movies/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(movieData),
    });
    return handleResponse(res);
  },

  async deleteMovie(id: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/movies/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Showtimes
  async getShowtimes(params?: { movieId?: string; date?: string }): Promise<{ showtimes: Showtime[] }> {
    const query = new URLSearchParams();
    if (params?.movieId) query.append('movieId', params.movieId);
    if (params?.date) query.append('date', params.date);

    const res = await fetch(`${API_BASE}/showtimes?${query.toString()}`);
    return handleResponse(res);
  },

  async getShowtime(id: string): Promise<{ showtime: Showtime }> {
    const res = await fetch(`${API_BASE}/showtimes/${id}`);
    return handleResponse(res);
  },

  async createShowtime(data: any): Promise<{ showtime: Showtime; message: string }> {
    const res = await fetch(`${API_BASE}/showtimes`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data),
    });
    return handleResponse(res);
  },

  async deleteShowtime(id: string): Promise<{ message: string }> {
    const res = await fetch(`${API_BASE}/showtimes/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Bookings
  async createBooking(bookingData: {
    showtimeId: string;
    movieId: string;
    seats: Array<{ seatNumber: string; tier: string; price: number }>;
    customerName: string;
    customerEmail: string;
    customerPhone?: string;
    paymentMethod: string;
  }): Promise<{ booking: Booking; message: string }> {
    const res = await fetch(`${API_BASE}/bookings`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(bookingData),
    });
    return handleResponse(res);
  },

  async getMyBookings(): Promise<{ bookings: Booking[] }> {
    const res = await fetch(`${API_BASE}/bookings/my`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  async getAllBookings(params?: { search?: string; status?: string }): Promise<{ bookings: Booking[] }> {
    const query = new URLSearchParams();
    if (params?.search) query.append('search', params.search);
    if (params?.status) query.append('status', params.status);

    const res = await fetch(`${API_BASE}/bookings/all?${query.toString()}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  async cancelBooking(id: string): Promise<{ booking: Booking; message: string }> {
    const res = await fetch(`${API_BASE}/bookings/${id}/cancel`, {
      method: 'PUT',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Admin Stats
  async getCinemaStats(): Promise<{ stats: CinemaStats }> {
    const res = await fetch(`${API_BASE}/stats`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },
};

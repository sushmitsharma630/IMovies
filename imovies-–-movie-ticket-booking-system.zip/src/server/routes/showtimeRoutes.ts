import { Router, Response } from 'express';
import { Showtime } from '../models/Showtime.ts';
import { Movie } from '../models/Movie.ts';
import { isConnectedToMongo, memoryStore } from '../db.ts';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Get showtimes (filtered by movieId and/or date)
router.get('/', async (req: any, res: Response) => {
  try {
    const { movieId, date } = req.query;

    if (isConnectedToMongo) {
      const query: any = {};
      if (movieId) query.movieId = movieId;
      if (date) query.date = date;

      const showtimes = await Showtime.find(query).populate('movieId', 'title posterUrl duration rating');
      res.json({ success: true, count: showtimes.length, showtimes });
    } else {
      // Memory fallback
      let showtimes = [...memoryStore.showtimes];
      if (movieId) {
        showtimes = showtimes.filter((s) => s.movieId.toString() === movieId.toString());
      }
      if (date) {
        showtimes = showtimes.filter((s) => s.date === date);
      }

      // Populate movie info
      const populated = showtimes.map((s) => {
        const movie = memoryStore.movies.find((m) => m._id.toString() === s.movieId.toString());
        return {
          ...s,
          movieId: movie
            ? {
                _id: movie._id,
                title: movie.title,
                posterUrl: movie.posterUrl,
                duration: movie.duration,
                rating: movie.rating,
              }
            : s.movieId,
        };
      });

      res.json({ success: true, count: populated.length, showtimes: populated });
    }
  } catch (err: any) {
    console.error('Fetch showtimes error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch showtimes.' });
  }
});

// Get single showtime by ID
router.get('/:id', async (req: any, res: Response) => {
  try {
    const { id } = req.params;

    if (isConnectedToMongo) {
      const showtime = await Showtime.findById(id).populate('movieId');
      if (!showtime) {
        res.status(404).json({ success: false, message: 'Showtime not found.' });
        return;
      }
      res.json({ success: true, showtime });
    } else {
      const showtime = memoryStore.showtimes.find((s) => s._id.toString() === id);
      if (!showtime) {
        res.status(404).json({ success: false, message: 'Showtime not found.' });
        return;
      }
      const movie = memoryStore.movies.find((m) => m._id.toString() === showtime.movieId.toString());
      res.json({
        success: true,
        showtime: {
          ...showtime,
          movieId: movie || showtime.movieId,
        },
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch showtime.' });
  }
});

// Admin: Create Showtime
router.post('/', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { movieId, cinemaHall, date, time, format, pricing, totalSeats } = req.body;

    if (!movieId || !cinemaHall || !date || !time) {
      res.status(400).json({ success: false, message: 'Movie, cinema hall, date, and time are required.' });
      return;
    }

    const priceConfig = {
      silver: Number(pricing?.silver) || 220,
      gold: Number(pricing?.gold) || 350,
      platinum: Number(pricing?.platinum) || 520,
    };

    if (isConnectedToMongo) {
      const movieExists = await Movie.findById(movieId);
      if (!movieExists) {
        res.status(404).json({ success: false, message: 'Target movie does not exist.' });
        return;
      }

      const newShowtime = await Showtime.create({
        movieId,
        cinemaHall,
        date,
        time,
        format: format || 'Dolby Atmos 2D',
        pricing: priceConfig,
        bookedSeats: [],
        totalSeats: Number(totalSeats) || 64,
      });

      res.status(201).json({ success: true, message: 'Showtime scheduled successfully!', showtime: newShowtime });
    } else {
      const movieExists = memoryStore.movies.find((m) => m._id.toString() === movieId.toString());
      if (!movieExists) {
        res.status(404).json({ success: false, message: 'Target movie does not exist.' });
        return;
      }

      const idHex = '67be' + Date.now().toString(16).padStart(20, '0');
      const newShowtime = {
        _id: idHex,
        movieId,
        cinemaHall,
        date,
        time,
        format: format || 'Dolby Atmos 2D',
        pricing: priceConfig,
        bookedSeats: [],
        totalSeats: Number(totalSeats) || 64,
        createdAt: new Date(),
      };

      memoryStore.showtimes.push(newShowtime);
      res.status(201).json({ success: true, message: 'Showtime scheduled successfully!', showtime: newShowtime });
    }
  } catch (err: any) {
    console.error('Create showtime error:', err);
    res.status(500).json({ success: false, message: err.message || 'Failed to create showtime.' });
  }
});

// Admin: Delete Showtime
router.delete('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;

    if (isConnectedToMongo) {
      const deleted = await Showtime.findByIdAndDelete(id);
      if (!deleted) {
        res.status(404).json({ success: false, message: 'Showtime not found.' });
        return;
      }
      res.json({ success: true, message: 'Showtime deleted successfully.' });
    } else {
      const idx = memoryStore.showtimes.findIndex((s) => s._id.toString() === id);
      if (idx === -1) {
        res.status(404).json({ success: false, message: 'Showtime not found.' });
        return;
      }
      memoryStore.showtimes.splice(idx, 1);
      res.json({ success: true, message: 'Showtime deleted successfully.' });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to delete showtime.' });
  }
});

export default router;

import { Router, Response } from 'express';
import { Booking } from '../models/Booking.ts';
import { Showtime } from '../models/Showtime.ts';
import { Movie } from '../models/Movie.ts';
import { isConnectedToMongo, memoryStore, seatLockManager } from '../db.ts';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Create a new booking with ATOMIC concurrency seat locking
router.post('/', verifyToken, async (req: AuthRequest, res: Response) => {
  const {
    showtimeId,
    movieId,
    seats, // [{ seatNumber: 'C4', tier: 'gold', price: 420 }, ...]
    customerName,
    customerEmail,
    customerPhone,
    paymentMethod,
  } = req.body;

  if (!showtimeId || !seats || !Array.isArray(seats) || seats.length === 0) {
    res.status(400).json({ success: false, message: 'Invalid booking data. Please select at least one seat.' });
    return;
  }

  const seatNumbers = seats.map((s: any) => s.seatNumber);

  // 1. Acquire mutex lock on requested seats
  const lockAcquired = seatLockManager.acquireLock(showtimeId, seatNumbers);
  if (!lockAcquired) {
    res.status(409).json({
      success: false,
      message: 'One or more selected seats are currently being locked by another customer. Please choose different seats.',
    });
    return;
  }

  try {
    let showtimeData: any;
    let movieData: any;

    if (isConnectedToMongo) {
      // 2. ATOMIC MongoDB findOneAndUpdate query ensuring no seats are in bookedSeats
      showtimeData = await Showtime.findOneAndUpdate(
        {
          _id: showtimeId,
          bookedSeats: { $nin: seatNumbers },
        },
        {
          $push: { bookedSeats: { $each: seatNumbers } },
        },
        { new: true }
      );

      if (!showtimeData) {
        seatLockManager.releaseLock(showtimeId, seatNumbers);
        res.status(409).json({
          success: false,
          message: 'Conflict: One or more selected seats have already been booked. Please choose other seats.',
        });
        return;
      }

      movieData = await Movie.findById(showtimeData.movieId);
    } else {
      // Memory Store atomic check & lock
      showtimeData = memoryStore.showtimes.find((s) => s._id.toString() === showtimeId.toString());
      if (!showtimeData) {
        seatLockManager.releaseLock(showtimeId, seatNumbers);
        res.status(404).json({ success: false, message: 'Showtime not found.' });
        return;
      }

      // Concurrency check: verify no requested seat is already booked
      const isAlreadyBooked = seatNumbers.some((seat) => showtimeData.bookedSeats.includes(seat));
      if (isAlreadyBooked) {
        seatLockManager.releaseLock(showtimeId, seatNumbers);
        res.status(409).json({
          success: false,
          message: 'Conflict: One or more selected seats have already been booked by another user. Please select other available seats.',
        });
        return;
      }

      // Atomically add to bookedSeats
      showtimeData.bookedSeats.push(...seatNumbers);
      movieData = memoryStore.movies.find((m) => m._id.toString() === showtimeData.movieId.toString());
    }

    // Calculate subtotal, convenience fee, tax, and grand total
    const subtotal = seats.reduce((sum: number, s: any) => sum + (Number(s.price) || 0), 0);
    const convenienceFee = Math.round(seats.length * 25);
    const taxAmount = Number(((subtotal + convenienceFee) * 0.09).toFixed(2));
    const grandTotal = Number((subtotal + convenienceFee + taxAmount).toFixed(2));

    const bookingNumber = 'IMV-' + Math.floor(100000 + Math.random() * 900000);

    const bookingPayload = {
      bookingNumber,
      userId: req.user?.id,
      showtimeId: showtimeData._id,
      movieId: movieData?._id || showtimeData.movieId,
      movieTitle: movieData?.title || 'Featured Film',
      moviePoster: movieData?.posterUrl || '',
      cinemaHall: showtimeData.cinemaHall,
      showDate: showtimeData.date,
      showTime: showtimeData.time,
      format: showtimeData.format,
      seats: seats.map((s) => ({
        seatNumber: s.seatNumber,
        tier: s.tier,
        price: Number(s.price),
      })),
      subtotal,
      convenienceFee,
      taxAmount,
      grandTotal,
      paymentMethod: paymentMethod || 'UPI / Card',
      paymentStatus: 'completed' as const,
      bookingStatus: 'confirmed' as const,
      customerName: customerName || req.user?.name || 'Valued Guest',
      customerEmail: customerEmail || req.user?.email || '',
      customerPhone: customerPhone || '',
      createdAt: new Date(),
    };

    let savedBooking: any;
    if (isConnectedToMongo) {
      savedBooking = await Booking.create(bookingPayload);
    } else {
      const idHex = '67bb' + Date.now().toString(16).padStart(20, '0');
      savedBooking = { _id: idHex, ...bookingPayload };
      memoryStore.bookings.unshift(savedBooking);
    }

    // Release in-memory lock now that seats are committed to DB
    seatLockManager.releaseLock(showtimeId, seatNumbers);

    res.status(201).json({
      success: true,
      message: 'Tickets booked successfully! Confirmation number: ' + bookingNumber,
      booking: savedBooking,
    });
  } catch (err: any) {
    seatLockManager.releaseLock(showtimeId, seatNumbers);
    console.error('Booking creation error:', err);
    res.status(500).json({ success: false, message: err.message || 'An error occurred during booking.' });
  }
});

// Get user's own bookings
router.get('/my', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;

    if (isConnectedToMongo) {
      const bookings = await Booking.find({ userId }).sort({ createdAt: -1 });
      res.json({ success: true, count: bookings.length, bookings });
    } else {
      const bookings = memoryStore.bookings
        .filter((b) => b.userId.toString() === userId?.toString())
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      res.json({ success: true, count: bookings.length, bookings });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch your bookings.' });
  }
});

// Admin: Get all bookings across the cinema
router.get('/all', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { search, status } = req.query;

    if (isConnectedToMongo) {
      const query: any = {};
      if (status && status !== 'all') {
        query.bookingStatus = status;
      }
      if (search) {
        query.$or = [
          { bookingNumber: { $regex: search, $options: 'i' } },
          { customerName: { $regex: search, $options: 'i' } },
          { customerEmail: { $regex: search, $options: 'i' } },
          { movieTitle: { $regex: search, $options: 'i' } },
        ];
      }
      const bookings = await Booking.find(query).sort({ createdAt: -1 });
      res.json({ success: true, count: bookings.length, bookings });
    } else {
      let bookings = [...memoryStore.bookings];

      if (status && status !== 'all') {
        bookings = bookings.filter((b) => b.bookingStatus === status);
      }

      if (search) {
        const s = (search as string).toLowerCase();
        bookings = bookings.filter(
          (b) =>
            b.bookingNumber.toLowerCase().includes(s) ||
            b.customerName.toLowerCase().includes(s) ||
            b.customerEmail.toLowerCase().includes(s) ||
            b.movieTitle.toLowerCase().includes(s)
        );
      }

      bookings.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      res.json({ success: true, count: bookings.length, bookings });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch all bookings.' });
  }
});

// Cancel a booking and release the seats back to the showtime
router.put('/:id/cancel', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;

    if (isConnectedToMongo) {
      const booking = await Booking.findById(id);
      if (!booking) {
        res.status(404).json({ success: false, message: 'Booking not found.' });
        return;
      }

      // Check permission: user can cancel their own, admin can cancel any
      if (req.user?.role !== 'admin' && booking.userId.toString() !== req.user?.id) {
        res.status(403).json({ success: false, message: 'Unauthorized to cancel this booking.' });
        return;
      }

      if (booking.bookingStatus === 'cancelled') {
        res.status(400).json({ success: false, message: 'Booking has already been cancelled.' });
        return;
      }

      booking.bookingStatus = 'cancelled';
      booking.paymentStatus = 'cancelled';
      await booking.save();

      // Release seats from showtime
      const seatNums = booking.seats.map((s: any) => s.seatNumber);
      await Showtime.findByIdAndUpdate(booking.showtimeId, {
        $pull: { bookedSeats: { $in: seatNums } },
      });

      res.json({ success: true, message: 'Booking cancelled and seats have been released.', booking });
    } else {
      const booking = memoryStore.bookings.find((b) => b._id.toString() === id);
      if (!booking) {
        res.status(404).json({ success: false, message: 'Booking not found.' });
        return;
      }

      if (req.user?.role !== 'admin' && booking.userId.toString() !== req.user?.id) {
        res.status(403).json({ success: false, message: 'Unauthorized to cancel this booking.' });
        return;
      }

      if (booking.bookingStatus === 'cancelled') {
        res.status(400).json({ success: false, message: 'Booking has already been cancelled.' });
        return;
      }

      booking.bookingStatus = 'cancelled';
      booking.paymentStatus = 'cancelled';

      // Release seats in showtime
      const showtime = memoryStore.showtimes.find((s) => s._id.toString() === booking.showtimeId.toString());
      if (showtime) {
        const seatNums = booking.seats.map((s: any) => s.seatNumber);
        showtime.bookedSeats = showtime.bookedSeats.filter((s: string) => !seatNums.includes(s));
      }

      res.json({ success: true, message: 'Booking cancelled and seats have been released.', booking });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to cancel booking.' });
  }
});

export default router;

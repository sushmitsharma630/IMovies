import { Router, Response } from 'express';
import { Booking } from '../models/Booking.ts';
import { Movie } from '../models/Movie.ts';
import { Showtime } from '../models/Showtime.ts';
import { isConnectedToMongo, memoryStore } from '../db.ts';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth.ts';

const router = Router();

router.get('/', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    if (isConnectedToMongo) {
      const totalMovies = await Movie.countDocuments();
      const activeMovies = await Movie.countDocuments({ status: 'now_showing' });
      const totalShowtimes = await Showtime.countDocuments();

      const confirmedBookings = await Booking.find({ bookingStatus: 'confirmed' });
      const totalRevenue = confirmedBookings.reduce((sum, b) => sum + b.grandTotal, 0);
      const totalTicketsSold = confirmedBookings.reduce((sum, b) => sum + b.seats.length, 0);

      // Average occupancy
      const showtimes = await Showtime.find();
      const totalSeatsCapacity = showtimes.reduce((sum, s) => sum + s.totalSeats, 0);
      const totalBookedSeats = showtimes.reduce((sum, s) => sum + s.bookedSeats.length, 0);
      const averageOccupancy = totalSeatsCapacity > 0 ? ((totalBookedSeats / totalSeatsCapacity) * 100).toFixed(1) : '0.0';

      res.json({
        success: true,
        stats: {
          totalRevenue: Math.round(totalRevenue),
          totalBookings: confirmedBookings.length,
          totalTicketsSold,
          totalMovies,
          activeMovies,
          totalShowtimes,
          averageOccupancy: `${averageOccupancy}%`,
        },
      });
    } else {
      const totalMovies = memoryStore.movies.length;
      const activeMovies = memoryStore.movies.filter((m) => m.status === 'now_showing').length;
      const totalShowtimes = memoryStore.showtimes.length;

      const confirmedBookings = memoryStore.bookings.filter((b) => b.bookingStatus === 'confirmed');
      const totalRevenue = confirmedBookings.reduce((sum, b) => sum + b.grandTotal, 0);
      const totalTicketsSold = confirmedBookings.reduce((sum, b) => sum + b.seats.length, 0);

      const totalSeatsCapacity = memoryStore.showtimes.reduce((sum, s) => sum + (s.totalSeats || 64), 0);
      const totalBookedSeats = memoryStore.showtimes.reduce((sum, s) => sum + (s.bookedSeats?.length || 0), 0);
      const averageOccupancy = totalSeatsCapacity > 0 ? ((totalBookedSeats / totalSeatsCapacity) * 100).toFixed(1) : '0.0';

      res.json({
        success: true,
        stats: {
          totalRevenue: Math.round(totalRevenue),
          totalBookings: confirmedBookings.length,
          totalTicketsSold,
          totalMovies,
          activeMovies,
          totalShowtimes,
          averageOccupancy: `${averageOccupancy}%`,
        },
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to calculate cinema statistics.' });
  }
});

export default router;

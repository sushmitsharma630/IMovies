import { Router, Response } from 'express';
import { Movie } from '../models/Movie.ts';
import { isConnectedToMongo, memoryStore } from '../db.ts';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Get all movies with search & filter support
router.get('/', async (req: any, res: Response) => {
  try {
    const { search, genre, status } = req.query;

    if (isConnectedToMongo) {
      const query: any = {};
      if (search) {
        query.title = { $regex: search, $options: 'i' };
      }
      if (genre && genre !== 'All') {
        query.genre = { $in: [genre] };
      }
      if (status && status !== 'all') {
        query.status = status;
      }

      const movies = await Movie.find(query).sort({ featured: -1, createdAt: -1 });
      res.json({ success: true, count: movies.length, movies });
    } else {
      // Memory fallback
      let movies = [...memoryStore.movies];

      if (search) {
        const s = (search as string).toLowerCase();
        movies = movies.filter(
          (m) =>
            m.title.toLowerCase().includes(s) ||
            m.description.toLowerCase().includes(s) ||
            m.director.toLowerCase().includes(s)
        );
      }

      if (genre && genre !== 'All') {
        movies = movies.filter((m) => m.genre.some((g: string) => g.toLowerCase() === (genre as string).toLowerCase()));
      }

      if (status && status !== 'all') {
        movies = movies.filter((m) => m.status === status);
      }

      // Sort featured first
      movies.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));

      res.json({ success: true, count: movies.length, movies });
    }
  } catch (err: any) {
    console.error('Fetch movies error:', err);
    res.status(500).json({ success: false, message: 'Failed to fetch movies.' });
  }
});

// Get movie by ID
router.get('/:id', async (req: any, res: Response) => {
  try {
    const { id } = req.params;

    if (isConnectedToMongo) {
      const movie = await Movie.findById(id);
      if (!movie) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }
      res.json({ success: true, movie });
    } else {
      const movie = memoryStore.movies.find((m) => m._id.toString() === id);
      if (!movie) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }
      res.json({ success: true, movie });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to fetch movie details.' });
  }
});

// Admin: Create Movie
router.post('/', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const {
      title,
      description,
      genre,
      duration,
      rating,
      imdbRating,
      releaseDate,
      posterUrl,
      bannerUrl,
      trailerUrl,
      director,
      cast,
      language,
      status,
      featured,
    } = req.body;

    if (!title || !description || !posterUrl) {
      res.status(400).json({ success: false, message: 'Title, description, and poster URL are required.' });
      return;
    }

    const genreList = Array.isArray(genre) ? genre : (genre || 'Action').split(',').map((g: string) => g.trim());
    const castList = Array.isArray(cast) ? cast : (cast || '').split(',').map((c: string) => c.trim()).filter(Boolean);

    if (isConnectedToMongo) {
      const newMovie = await Movie.create({
        title: title.trim(),
        description: description.trim(),
        genre: genreList,
        duration: Number(duration) || 120,
        rating: rating || 'UA 16+',
        imdbRating: Number(imdbRating) || 8.0,
        releaseDate: releaseDate || new Date().toISOString().split('T')[0],
        posterUrl,
        bannerUrl: bannerUrl || posterUrl,
        trailerUrl: trailerUrl || '',
        director: director || '',
        cast: castList,
        language: language || 'English',
        status: status || 'now_showing',
        featured: Boolean(featured),
      });

      res.status(201).json({ success: true, message: 'Movie added successfully!', movie: newMovie });
    } else {
      const idHex = '67bd' + Date.now().toString(16).padStart(20, '0');
      const newMovie = {
        _id: idHex,
        title: title.trim(),
        description: description.trim(),
        genre: genreList,
        duration: Number(duration) || 120,
        rating: rating || 'UA 16+',
        imdbRating: Number(imdbRating) || 8.0,
        releaseDate: releaseDate || new Date().toISOString().split('T')[0],
        posterUrl,
        bannerUrl: bannerUrl || posterUrl,
        trailerUrl: trailerUrl || '',
        director: director || '',
        cast: castList,
        language: language || 'English',
        status: status || 'now_showing',
        featured: Boolean(featured),
        createdAt: new Date(),
      };

      memoryStore.movies.unshift(newMovie);
      res.status(201).json({ success: true, message: 'Movie added successfully!', movie: newMovie });
    }
  } catch (err: any) {
    console.error('Create movie error:', err);
    res.status(500).json({ success: false, message: err.message || 'Failed to create movie.' });
  }
});

// Admin: Update Movie
router.put('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    if (updates.genre && typeof updates.genre === 'string') {
      updates.genre = updates.genre.split(',').map((g: string) => g.trim());
    }
    if (updates.cast && typeof updates.cast === 'string') {
      updates.cast = updates.cast.split(',').map((c: string) => c.trim()).filter(Boolean);
    }

    if (isConnectedToMongo) {
      const updatedMovie = await Movie.findByIdAndUpdate(id, updates, { new: true });
      if (!updatedMovie) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }
      res.json({ success: true, message: 'Movie updated successfully!', movie: updatedMovie });
    } else {
      const idx = memoryStore.movies.findIndex((m) => m._id.toString() === id);
      if (idx === -1) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }

      memoryStore.movies[idx] = { ...memoryStore.movies[idx], ...updates, updatedAt: new Date() };
      res.json({ success: true, message: 'Movie updated successfully!', movie: memoryStore.movies[idx] });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to update movie.' });
  }
});

// Admin: Delete Movie
router.delete('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;

    if (isConnectedToMongo) {
      const deletedMovie = await Movie.findByIdAndDelete(id);
      if (!deletedMovie) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }
      // Clean up showtimes
      const { Showtime } = await import('../models/Showtime.ts');
      await Showtime.deleteMany({ movieId: id });
      res.json({ success: true, message: 'Movie and associated showtimes removed successfully.' });
    } else {
      const idx = memoryStore.movies.findIndex((m) => m._id.toString() === id);
      if (idx === -1) {
        res.status(404).json({ success: false, message: 'Movie not found.' });
        return;
      }

      memoryStore.movies.splice(idx, 1);
      memoryStore.showtimes = memoryStore.showtimes.filter((s) => s.movieId.toString() !== id);
      res.json({ success: true, message: 'Movie and associated showtimes removed successfully.' });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to delete movie.' });
  }
});

export default router;

import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { User } from '../models/User.ts';
import { isConnectedToMongo, memoryStore } from '../db.ts';
import { generateToken, verifyToken, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Register new user
router.post('/register', async (req: any, res: Response) => {
  try {
    const { name, email, password, phone, role } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ success: false, message: 'Please provide name, email, and password.' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();

    if (isConnectedToMongo) {
      const existingUser = await User.findOne({ email: cleanEmail });
      if (existingUser) {
        res.status(400).json({ success: false, message: 'An account with this email address already exists.' });
        return;
      }

      const newUser = await User.create({
        name: name.trim(),
        email: cleanEmail,
        password,
        phone: phone || '',
        role: role === 'admin' ? 'admin' : 'user',
      });

      const token = generateToken(newUser);
      res.status(201).json({
        success: true,
        message: 'Registration successful!',
        token,
        user: {
          id: newUser._id.toString(),
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
          phone: newUser.phone,
        },
      });
    } else {
      // Memory fallback
      const existing = memoryStore.users.find((u) => u.email.toLowerCase() === cleanEmail);
      if (existing) {
        res.status(400).json({ success: false, message: 'An account with this email address already exists.' });
        return;
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const newUserId = '67ba' + Date.now().toString(16).padStart(20, '0');
      const newUser = {
        _id: newUserId,
        name: name.trim(),
        email: cleanEmail,
        password: hashedPassword,
        phone: phone || '',
        role: role === 'admin' ? 'admin' : 'user',
        createdAt: new Date(),
      };

      memoryStore.users.push(newUser);
      const token = generateToken(newUser);

      res.status(201).json({
        success: true,
        message: 'Registration successful!',
        token,
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
          phone: newUser.phone,
        },
      });
    }
  } catch (err: any) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: err.message || 'Server error during registration.' });
  }
});

// Login user
router.post('/login', async (req: any, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ success: false, message: 'Please enter both email and password.' });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();

    if (isConnectedToMongo) {
      const user = await User.findOne({ email: cleanEmail });
      if (!user) {
        res.status(401).json({ success: false, message: 'Invalid email or password.' });
        return;
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        res.status(401).json({ success: false, message: 'Invalid email or password.' });
        return;
      }

      const token = generateToken(user);
      res.json({
        success: true,
        message: 'Login successful!',
        token,
        user: {
          id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
        },
      });
    } else {
      // Memory fallback
      const user = memoryStore.users.find((u) => u.email.toLowerCase() === cleanEmail);
      if (!user) {
        res.status(401).json({ success: false, message: 'Invalid email or password.' });
        return;
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        res.status(401).json({ success: false, message: 'Invalid email or password.' });
        return;
      }

      const token = generateToken(user);
      res.json({
        success: true,
        message: 'Login successful!',
        token,
        user: {
          id: user._id.toString(),
          name: user.name,
          email: user.email,
          role: user.role,
          phone: user.phone,
        },
      });
    }
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: err.message || 'Server error during login.' });
  }
});

// Get current user profile
router.get('/me', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    if (isConnectedToMongo) {
      const user = await User.findById(req.user?.id).select('-password');
      if (!user) {
        res.status(404).json({ success: false, message: 'User not found.' });
        return;
      }
      res.json({ success: true, user });
    } else {
      const user = memoryStore.users.find((u) => u._id.toString() === req.user?.id);
      if (!user) {
        res.status(404).json({ success: false, message: 'User not found.' });
        return;
      }
      const { password, ...safeUser } = user;
      res.json({ success: true, user: safeUser });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Failed to retrieve profile.' });
  }
});

export default router;

import mongoose from 'mongoose';
import { User } from './models/User.ts';
import { Movie } from './models/Movie.ts';
import { Showtime } from './models/Showtime.ts';
import { Booking } from './models/Booking.ts';

// In-memory data fallback store for seamless demonstration when local mongod is not running
export let isConnectedToMongo = false;

// In-memory atomic seat booking lock manager
export const seatLockManager = {
  // map of showtimeId -> Set of seat identifiers
  locks: new Map<string, Set<string>>(),

  acquireLock(showtimeId: string, seats: string[]): boolean {
    let currentLocks = this.locks.get(showtimeId);
    if (!currentLocks) {
      currentLocks = new Set<string>();
      this.locks.set(showtimeId, currentLocks);
    }
    // Check if any seat is already locked
    for (const s of seats) {
      if (currentLocks.has(s)) {
        return false;
      }
    }
    // Lock all seats
    for (const s of seats) {
      currentLocks.add(s);
    }
    return true;
  },

  releaseLock(showtimeId: string, seats: string[]) {
    const currentLocks = this.locks.get(showtimeId);
    if (currentLocks) {
      for (const s of seats) {
        currentLocks.delete(s);
      }
    }
  },
};

export async function connectDB() {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/imovies';

  try {
    // Attempt connecting to real MongoDB instance with 2-second timeout
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2000,
    });
    isConnectedToMongo = true;
    console.log(`[MongoDB] Connected successfully to ${uri}`);
    await seedInitialData();
  } catch (err: any) {
    console.log(`[Database Notice] External MongoDB server not detected (${err.message}).`);
    console.log(`[Database Notice] Initializing High-Performance MongoDB/Mongoose Simulation Storage with atomic seat locks.`);
    isConnectedToMongo = false;
    await seedMemoryData();
  }
}

// Memory database store for fallback
export const memoryStore = {
  users: [] as any[],
  movies: [] as any[],
  showtimes: [] as any[],
  bookings: [] as any[],
};

// Default seed movies with generated cinema poster assets
export const seedMoviesData = [
  {
    _id: '67bd00000000000000000001',
    title: 'Interstellar: The Final Horizon',
    description: 'When an enigmatic anomaly emerges near Saturn, a courageous crew of astrophysicists voyages beyond the event horizon to unlock humanity\'s salvation across interstellar space.',
    genre: ['Sci-Fi', 'Adventure', 'Drama'],
    duration: 169,
    rating: 'PG-13',
    imdbRating: 8.9,
    releaseDate: '2026-10-15',
    posterUrl: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg',
    bannerUrl: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg',
    trailerUrl: 'https://www.youtube.com/watch?v=zSWdZVtXT7E',
    director: 'Christopher Vance',
    cast: ['Mark Adams', 'Mara Chen', 'Leo Khan', 'Elena Vance'],
    language: 'English (Dolby Atmos)',
    status: 'now_showing',
    featured: true,
  },
  {
    _id: '67bd00000000000000000002',
    title: 'The Silent City: Crimson Rain',
    description: 'In the rain-drenched neon alleys of a ruthless metropolis, a disgraced detective unearths a syndicate conspiracy that reaches the highest offices of justice.',
    genre: ['Thriller', 'Crime', 'Mystery'],
    duration: 142,
    rating: 'R',
    imdbRating: 8.6,
    releaseDate: '2026-10-20',
    posterUrl: '/src/assets/images/poster_crimson_shadows_1793091325938.jpg',
    bannerUrl: '/src/assets/images/poster_crimson_shadows_1793091325938.jpg',
    trailerUrl: 'https://www.youtube.com/watch?v=mqqft2x_Aa4',
    director: 'Elias Vance',
    cast: ['Marcus Raven', 'Elena Stone', 'David Alvarez', 'Sarah Morgan'],
    language: 'English',
    status: 'now_showing',
    featured: true,
  },
  {
    _id: '67bd00000000000000000003',
    title: 'Synth-Hunter: Apex Protocol',
    description: 'Set in 2088 New Tokyo, an augmented cyber operative must hunt down rogue sentient combat droids before an orbital network overrides global defenses.',
    genre: ['Action', 'Sci-Fi', 'Cyberpunk'],
    duration: 135,
    rating: 'UA 16+',
    imdbRating: 8.4,
    releaseDate: '2026-10-24',
    posterUrl: '/src/assets/images/poster_cyber_nexus_1793091326294.jpg',
    bannerUrl: '/src/assets/images/poster_cyber_nexus_1793091326294.jpg',
    trailerUrl: 'https://www.youtube.com/watch?v=8qB8EGNOtr8',
    director: 'Mamoru Tanaka',
    cast: ['Kairo Aris', 'Jena Walker', 'Kenji Sato', 'Tanya Cross'],
    language: 'English / Japanese (Dual)',
    status: 'now_showing',
    featured: false,
  },
  {
    _id: '67bd00000000000000000004',
    title: 'The Celestial Realms: Twin Moons',
    description: 'An ancient prophecy awakens as twin celestial moons align over the misty kingdom of Aethelgard, forcing three estranged guardians to embark on a mythic quest.',
    genre: ['Fantasy', 'Adventure', 'Family'],
    duration: 154,
    rating: 'PG-13',
    imdbRating: 8.7,
    releaseDate: '2026-11-12',
    posterUrl: '/src/assets/images/poster_enchanted_kingdom_1793091326406.jpg',
    bannerUrl: '/src/assets/images/poster_enchanted_kingdom_1793091326406.jpg',
    trailerUrl: 'https://www.youtube.com/watch?v=0hURb63z600',
    director: 'Guillermo Sterling',
    cast: ['Arthur Drake', 'Eliza Vance', 'Korin Blackwood', 'Sylvan Thresh'],
    language: 'English',
    status: 'coming_soon',
    featured: false,
  },
];

// Helper to seed Showtimes across next 7 days
function generateSeedShowtimes(moviesList: any[]) {
  const showtimes: any[] = [];
  const halls = [
    { name: 'Screen 1 – IMAX Laser & Dolby Atmos', format: 'IMAX 3D', silver: 280, gold: 420, platinum: 600 },
    { name: 'Screen 2 – VIP Luxe Recliner Suite', format: 'VIP Luxe', silver: 350, gold: 500, platinum: 750 },
    { name: 'Screen 3 – 4DX Dynamic Motion', format: '4DX', silver: 300, gold: 450, platinum: 620 },
  ];

  const times = ['10:30 AM', '02:00 PM', '05:45 PM', '09:15 PM'];
  let idCounter = 1;

  // Generate for today and next 6 days
  for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
    const d = new Date();
    d.setDate(d.getDate() + dayOffset);
    const dateStr = d.toISOString().split('T')[0];

    moviesList.forEach((movie, mIdx) => {
      // Pick 2-3 showtimes per movie per day
      times.forEach((time, tIdx) => {
        const hall = halls[(mIdx + tIdx) % halls.length];
        // Pre-book a few realistic seats for demonstration
        const preBooked: string[] = [];
        if (dayOffset === 0 && (tIdx === 1 || tIdx === 2)) {
          preBooked.push('B3', 'B4', 'C5', 'C6', 'E7', 'E8');
        }

        const idHex = idCounter.toString(16).padStart(24, '0');
        showtimes.push({
          _id: idHex,
          movieId: movie._id,
          cinemaHall: hall.name,
          date: dateStr,
          time: time,
          format: hall.format,
          pricing: {
            silver: hall.silver,
            gold: hall.gold,
            platinum: hall.platinum,
          },
          bookedSeats: preBooked,
          totalSeats: 64,
          createdAt: new Date(),
        });
        idCounter++;
      });
    });
  }

  return showtimes;
}

// Memory seeder
export async function seedMemoryData() {
  const bcrypt = await import('bcryptjs');
  const hashedAdminPassword = await bcrypt.default.hash('Admin@123', 10);
  const hashedUserPassword = await bcrypt.default.hash('User@123', 10);

  memoryStore.users = [
    {
      _id: '67ba00000000000000000001',
      name: 'Cinema Admin',
      email: 'admin@imovies.com',
      password: hashedAdminPassword,
      role: 'admin',
      phone: '+1 800 555 0199',
      createdAt: new Date(),
    },
    {
      _id: '67ba00000000000000000002',
      name: 'John Doe',
      email: 'john@example.com',
      password: hashedUserPassword,
      role: 'user',
      phone: '+1 555 018 4422',
      createdAt: new Date(),
    },
  ];

  memoryStore.movies = [...seedMoviesData];
  memoryStore.showtimes = generateSeedShowtimes(memoryStore.movies);

  // Add initial sample booking
  const firstShow = memoryStore.showtimes[0];
  memoryStore.bookings = [
    {
      _id: '67bb00000000000000000001',
      bookingNumber: 'IMV-782914',
      userId: memoryStore.users[1]._id,
      showtimeId: firstShow._id,
      movieId: firstShow.movieId,
      movieTitle: 'Interstellar: The Final Horizon',
      moviePoster: '/src/assets/images/poster_interstellar_odyssey_1793091325671.jpg',
      cinemaHall: firstShow.cinemaHall,
      showDate: firstShow.date,
      showTime: firstShow.time,
      format: firstShow.format,
      seats: [
        { seatNumber: 'C5', tier: 'gold', price: 420 },
        { seatNumber: 'C6', tier: 'gold', price: 420 },
      ],
      subtotal: 840,
      convenienceFee: 40,
      taxAmount: 75.6,
      grandTotal: 955.6,
      paymentMethod: 'UPI',
      paymentStatus: 'completed',
      bookingStatus: 'confirmed',
      customerName: 'John Doe',
      customerEmail: 'john@example.com',
      customerPhone: '+1 555 018 4422',
      createdAt: new Date(),
    },
  ];

  console.log('[MemoryDB] Initialized with 4 movies, users, showtimes, and sample bookings.');
}

// Seed real MongoDB if connected
export async function seedInitialData() {
  try {
    const movieCount = await Movie.countDocuments();
    if (movieCount === 0) {
      console.log('[MongoDB] Seeding initial movie data...');
      await Movie.insertMany(seedMoviesData);
    }

    const userCount = await User.countDocuments();
    if (userCount === 0) {
      console.log('[MongoDB] Seeding admin and test users...');
      await User.create([
        {
          name: 'Cinema Admin',
          email: 'admin@imovies.com',
          password: 'Admin@123',
          role: 'admin',
          phone: '+1 800 555 0199',
        },
        {
          name: 'John Doe',
          email: 'john@example.com',
          password: 'User@123',
          role: 'user',
          phone: '+1 555 018 4422',
        },
      ]);
    }

    const showtimeCount = await Showtime.countDocuments();
    if (showtimeCount === 0) {
      console.log('[MongoDB] Generating initial showtimes...');
      const allMovies = await Movie.find();
      const seedShows = generateSeedShowtimes(allMovies);
      await Showtime.insertMany(seedShows);
    }
  } catch (err: any) {
    console.error('[MongoDB Seed Error]', err);
  }
}

import mongoose, { Document, Schema } from 'mongoose';

export interface IBookedSeatInfo {
  seatNumber: string;
  tier: 'silver' | 'gold' | 'platinum';
  price: number;
}

export interface IBooking extends Document {
  bookingNumber: string;
  userId: mongoose.Types.ObjectId;
  showtimeId: mongoose.Types.ObjectId;
  movieId: mongoose.Types.ObjectId;
  movieTitle: string;
  moviePoster: string;
  cinemaHall: string;
  showDate: string;
  showTime: string;
  format: string;
  seats: IBookedSeatInfo[];
  subtotal: number;
  convenienceFee: number;
  taxAmount: number;
  grandTotal: number;
  paymentMethod: string;
  paymentStatus: 'completed' | 'pending' | 'cancelled';
  bookingStatus: 'confirmed' | 'cancelled';
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  createdAt: Date;
}

const BookedSeatSchema = new Schema<IBookedSeatInfo>(
  {
    seatNumber: { type: String, required: true },
    tier: { type: String, enum: ['silver', 'gold', 'platinum'], required: true },
    price: { type: Number, required: true },
  },
  { _id: false }
);

const BookingSchema = new Schema<IBooking>(
  {
    bookingNumber: { type: String, required: true, unique: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    showtimeId: { type: Schema.Types.ObjectId, ref: 'Showtime', required: true },
    movieId: { type: Schema.Types.ObjectId, ref: 'Movie', required: true },
    movieTitle: { type: String, required: true },
    moviePoster: { type: String, required: true },
    cinemaHall: { type: String, required: true },
    showDate: { type: String, required: true },
    showTime: { type: String, required: true },
    format: { type: String, default: 'Standard 2D' },
    seats: { type: [BookedSeatSchema], required: true },
    subtotal: { type: Number, required: true },
    convenienceFee: { type: Number, required: true },
    taxAmount: { type: Number, required: true },
    grandTotal: { type: Number, required: true },
    paymentMethod: { type: String, default: 'UPI' },
    paymentStatus: { type: String, enum: ['completed', 'pending', 'cancelled'], default: 'completed' },
    bookingStatus: { type: String, enum: ['confirmed', 'cancelled'], default: 'confirmed' },
    customerName: { type: String, required: true },
    customerEmail: { type: String, required: true },
    customerPhone: { type: String, default: '' },
  },
  { timestamps: true }
);

export const Booking = mongoose.models.Booking || mongoose.model<IBooking>('Booking', BookingSchema);

import mongoose, { Document, Schema } from 'mongoose';

export interface IMovie extends Document {
  title: string;
  description: string;
  genre: string[];
  duration: number; // in minutes
  rating: string; // PG-13, R, etc.
  imdbRating: number;
  releaseDate: string;
  posterUrl: string;
  bannerUrl?: string;
  trailerUrl?: string;
  director: string;
  cast: string[];
  language: string;
  status: 'now_showing' | 'coming_soon';
  featured: boolean;
  createdAt: Date;
}

const MovieSchema = new Schema<IMovie>(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true },
    genre: { type: [String], required: true },
    duration: { type: Number, required: true },
    rating: { type: String, required: true, default: 'UA 16+' },
    imdbRating: { type: Number, required: true, default: 8.0 },
    releaseDate: { type: String, required: true },
    posterUrl: { type: String, required: true },
    bannerUrl: { type: String, default: '' },
    trailerUrl: { type: String, default: '' },
    director: { type: String, default: '' },
    cast: { type: [String], default: [] },
    language: { type: String, default: 'English' },
    status: { type: String, enum: ['now_showing', 'coming_soon'], default: 'now_showing' },
    featured: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export const Movie = mongoose.models.Movie || mongoose.model<IMovie>('Movie', MovieSchema);

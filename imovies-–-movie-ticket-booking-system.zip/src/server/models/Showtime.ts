import mongoose, { Document, Schema } from 'mongoose';

export interface IShowtimePricing {
  silver: number;
  gold: number;
  platinum: number;
}

export interface IShowtime extends Document {
  movieId: mongoose.Types.ObjectId;
  cinemaHall: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g., "07:30 PM"
  format: string; // "IMAX 3D", "Dolby Atmos", "4DX", "Standard 2D"
  pricing: IShowtimePricing;
  bookedSeats: string[];
  totalSeats: number;
  createdAt: Date;
}

const ShowtimeSchema = new Schema<IShowtime>(
  {
    movieId: { type: Schema.Types.ObjectId, ref: 'Movie', required: true },
    cinemaHall: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    format: { type: String, default: 'Dolby Atmos 2D' },
    pricing: {
      silver: { type: Number, default: 220 },
      gold: { type: Number, default: 350 },
      platinum: { type: Number, default: 520 },
    },
    bookedSeats: { type: [String], default: [] },
    totalSeats: { type: Number, default: 64 },
  },
  { timestamps: true }
);

// Index to ensure efficient lookup by movie and date
ShowtimeSchema.index({ movieId: 1, date: 1 });

export const Showtime = mongoose.models.Showtime || mongoose.model<IShowtime>('Showtime', ShowtimeSchema);
